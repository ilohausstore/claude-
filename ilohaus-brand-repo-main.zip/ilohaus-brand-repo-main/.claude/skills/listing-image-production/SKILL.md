---
name: listing-image-production
description: Makes or revises ilohaus Amazon listing images (main image + images 02–09) for one product, following the brand guidelines and the product's facts and references. Use for "make listing images", "redo image 04", "new listing set for <product>".
---

# Listing image production

## Inputs
- Product folder name (e.g. `03-terracotta-coaster-set`)
- Which images: full set, or specific numbers
- Any brief from the user (angle, what's underperforming)

## Steps

1. **Load context.** Read `CLAUDE.md`, the product's three .md files, then `01`, `02`, `03`, `07`, `08` in `docs/brand-guidelines-for-visuals/`. Faith product → also `06`.
2. **Open references.** Open every image in the product's `references/`. Write 3–6 bullets describing exactly what the product looks like. If references are missing or unclear, stop and ask.
3. **Plan.** Pick the sequence (A–E) from `08` §4, then fill the product's `listing-plan.md` (template in `_template/`): slot, image code, buyer question, headline, callouts/proof, scene. Use review complaints and SQP to decide slots 2–4. Show the plan to the user before generating (skip if they said "just make it").
4. **Generate.** Scene first, product accuracy second:
   - Generate the scene with the product matched to references.
   - If the product drifts, composite the real product photo onto the scene.
   - Never let the model render verses, product print or the logo. Overlay real artwork/text afterwards.
   - Add text overlays per `02` (fonts, sizes) and `08` (layout).
5. **Check.** Run the full checklist in `03-image-production-playbook.md` on each image. Fix fails before handover.
6. **Save.** `output/<product-folder>/<YYYY-MM-DD>/0N-<slug>.jpg`, 2000×2000, sRGB.
7. **Hand over.** One line per image: what it shows + checklist result. List any open issues.
8. **Feedback loop.** For feedback that should stick, ask "Save this as a rule?" → write to the product's `visual-identity.md` (product-specific) or propose a change to `08` (brand-wide, needs approval).

## Revising one image
Change only the requested image. Keep everything else identical. Save as `0N-<slug>-v2.jpg`.
