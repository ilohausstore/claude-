---
name: new-product-folder
description: Creates and fills a new ilohaus product folder from the template using the live listing, supplier info and photos. Use for "add a new product", "create product folder for <product>", "set up <ASIN> in the repo".
---

# New product folder

## Inputs
- Product name and parent ASIN
- Line: core or faith
- Any supplier spec, photos or listing link the user provides

## Steps

1. Find the next free number in `ilohaus-product-library/`. Copy `_template/` to `NN-<short-name>/` (lowercase, hyphens).
2. Fill `product-facts.md` from the live listing (title, bullets, dimensions) and supplier spec. Anything not confirmed → `TBC`. Faith: copy verse text exactly, mark translation, and check it against the KJV/WEB source.
3. Ask the user for 3–8 reference photos (front, set flat lay, macro texture, base, scale in hand, packaging). Save small copies (≤ 3MB, JPG) to `references/` as `ref-0N-<what>.jpg`. Note OneDrive paths of originals in `asset-evidence.md`.
4. Open each reference and fill `visual-identity.md`: shape, colours, finish, details AI usually gets wrong.
5. Fill `asset-evidence.md` detail → evidence table.
6. Add the product to the table in `ilohaus-product-library/README.md`.
7. Run a completeness check: list every `TBC` and empty field. Set status to `draft` until all are filled, then `complete`.
8. Commit: "Add product folder NN-<short-name>".
