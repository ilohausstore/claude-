# 08 — Listing image guide

How ilohaus builds Amazon listing images. Read with `02` (palette, fonts) and `03` (production + quality checklist).

Studied: KeaBabies (8pk Bandana Bibs B08G4SDDQC, 20k+ reviews; Baby Wrap B076KQHGC9) and Decorably (Kevan Soh, Sep 2026 mastermind). KeaBabies' aesthetic is baby-pastel and not ours. Their **system** is what we copy.

---

**Reference brands:** read `11-reference-brands.md` for what we take from Navy Peony, KeaBabies, Nook Theory, Naoki, Highmark Collective and Decorably.

## 1. Principles

1. **One image = one buyer question = one message.** Each image has a 2–5 word headline that answers it. KeaBabies: "Dual Layer Protection", "Grows With Your Baby", "Easy Steps to Self-Tie". Never two ideas on one image.
2. **Order by what makes or breaks the sale, not by a fixed template.** Most shoppers see images 1–4 and leave. The biggest objection or differentiator goes in slot 2 or 3. KeaBabies' own reviewer flagged that their "machine washable" claim sat too late in the stack. Don't repeat that.
3. **Alternate image types.** Infographic → lifestyle → infographic → lifestyle. KeaBabies never shows two dense infographics in a row. It keeps the swipe feeling light.
4. **Every infographic has a lifestyle twin.** Cut-out product with callouts proves it. People using it sell it. Do both for the key benefit.
5. **Callouts point at the thing.** Thin line with a dot from the label to the exact part of the product (KeaBabies image 2). No floating text bullets when you can point.
6. **Prove, don't claim.** A certification badge, a cross-section, a 3-step diagram or a measured size beats an adjective. "Absorbent" means nothing; a cork base close-up with water beading shows it.
7. **Show the box.** Gift-ready packaging gets its own slot or a circle inset (KeaBabies images 7 and 9). For ilohaus this is big: coasters and journals are bought as gifts.
8. **Mobile first.** Headline readable at 400px wide. Max ~12 words of text per image, excluding the small print.
9. **Consistency across the catalogue.** Same headline position, same font, same callout style on every ASIN. A shopper browsing three ilohaus listings should recognise the brand without seeing the logo.

## 2. Slot rules

| Slot | Job | Rule |
|---|---|---|
| 1 | Main image | Pure white (255,255,255), full set, product ~85% of frame, no text/props/logo. Fan or stagger a set so every design shows (KeaBabies image 1 shows all 8 bibs) |
| 2 | **Second main image** (HOOK) | The #1 reason to buy, or the #1 objection answered, on the product shown large. Must sell before the click. See §2a |
| 3 | Desire | Hero lifestyle. The "I want my home to feel like that" image |
| 4 | Proof | The detail that makes it better than the cheaper option |
| 5–7 | Questions | Size, what's in the set, how it works, ways to use |
| 8 | Gift / who it's for | Occasion + packaging |
| 9 | Close | Brand moment: lifestyle + tagline + logo. Or care/guarantee if that's a real objection |

Slots 2–4 change per product (see §4). Slot 1 never changes.

### 2a. Slot 2 is the second main image

Amazon now shows a swipeable image carousel in search results in a growing share of categories, and its search can swap in a gallery image instead of the main image when it predicts more clicks (sellers can't turn this off). So image 2 is often seen **before** the click, at thumbnail size, without the title next to it. Treat it as a second main image, not as page-two content.

KeaBabies pattern (83 listings checked, Oct 2026): image 2 is almost always the **same product, same angle as the main image, large, on a light cream background**, with **one 2–5 word benefit headline**, 2–4 pointed callouts and a size, age or certification badge. Very few are scenes without the product. Examples: "Dual Layer Protection", "4 Ultra-Soft Layers", "Generously Sized", "Larger. Obviously."

Rules for ilohaus slot 2:
- Product fills **60–70% of the frame**, same angle and set arrangement as MAIN, so a shopper swiping from image 1 recognises it instantly.
- Background Linen, or Linen with a Sand circle. Never a full lifestyle scene in slot 2.
- **One** benefit headline, 2–5 words, Josefin Sans Regular or SemiBold (never Light), big enough to read at ~400px wide.
- Max 3 pointed callouts. Dimensions in cm + in if size is a buying question.
- One proof badge max (cork base, KJV verses, food-safe, only if true).
- It must make sense with the title hidden: a shopper should know what the product is and why it's better from this image alone.
- Test: shrink the image to 300px. If the headline can't be read or the product isn't obvious, it fails.

## 3. The image library

Pick from these. Each has a fixed layout so the catalogue stays consistent.

| Code | Image type | Buyer question | Layout | KeaBabies example |
|---|---|---|---|---|
| **MAIN** | Main image | What is it? | White, product only | Bibs #1, Wrap #1 |
| **HOOK** | Key benefit infographic (second main image) | Why this one? | Product large (60–70%), same angle as MAIN, on Linen; 1 headline, 2–3 pointed callouts, 1 proof badge (§2a) | Bibs #2 "Dual Layer Protection" |
| **LIFE** | Hero lifestyle | How will it feel? | Full-bleed, lived-in scene with something happening (see `03` "Lived-in, not staged"); headline on a Linen card or clean wall, ≤ 1 callout | Bibs #4, Wrap #3; Nook Theory plates #2, #9 |
| **SET** | What's in the set | What exactly do I get? | Flat lay of every piece, count label, design names | Bibs #1 (doubles as main) |
| **DETAIL** | Design / material close-up | Is it good quality? | Macro shot or cutaway, 2–3 pointed callouts | Bibs #6 "Durable and Lasting Quality" |
| **HOW** | How it works, 3 steps | How do I use it? | 3 numbered panels left→right, 1 short line each | Wrap #7 "Easy Steps to Self-Tie" |
| **ADAPT** | Range / versatility | Will it fit my situation? | 3 circles or 3 panels showing the variants | Bibs #3 "Grows With Your Baby" (narrow/normal/widest) |
| **USES** | Ways to use it | What can I do with it? | Lifestyle + short list (≤ 4 items) on clean side | Bibs #5 "Great for…" |
| **SIZE** | Size | Will it fit? | Product next to a familiar object or hand, cm + in dimension lines | (Not used by KeaBabies. We always use it) |
| **WHO** | Who it's for | Is it for me / them? | Lifestyle of the buyer or recipient + 3–4 labels | Wrap #4 "Perfect for all body shapes" |
| **GIFT** | Gift-ready | Can I give it? | Product in packaging, occasion headline, packaging inset | Bibs #7, Wrap #9 "Registry Must-Have" |
| **EMOTION** | Emotional moment | Why does it matter? | Two people, real connection, minimal text | Wrap #8 "The Art of Bonding" |
| **CARE** | Care / durability | Is it easy to look after? | Small icon row (dishwasher, hand wash) on a DETAIL or CLOSE image | Bibs #6 wash icons, bottom-left |
| **CLOSE** | Closing brand image | Who are these people? | Lifestyle + tagline + logo, Linen band at bottom | Bibs #9 green band "Easy To Wear" |

## 4. Sequences by product type

Not every product needs every image. Pick the sequence that matches the product, then adjust slots 2–4 using review complaints and SQP (what shoppers worry about).

### A. Core: coaster set
1 MAIN · 2 HOOK (absorbent top / cork base, no sticking or sliding) · 3 LIFE (morning coffee) · 4 DETAIL (glaze, edge, base) · 5 SET (every design named) · 6 SIZE (under a mug, in hand) · 7 USES (coffee table, desk, plant pot, trivet if supported) · 8 GIFT (housewarming, box) · 9 CLOSE ("Joy lives here.")

### B. Core: bowls and plates
1 MAIN · 2 HOOK (the reason: stackable / chip-resistant / microwave-safe, whichever is true and most searched) · 3 LIFE (family table) · 4 SIZE (portion shown with real food, cm + in) · 5 DETAIL (glaze, rim, base) · 6 SET · 7 CARE (dishwasher, microwave, oven: icons only for what's supported) · 8 GIFT or WHO · 9 CLOSE

### C. Faith: journal or notebook
1 MAIN (cover verse legible) · 2 HOOK (inside pages: what makes it a devotional, not a blank notebook) · 3 LIFE (quiet devotion by a window) · 4 HOW (how to use it in 3 steps: read, reflect, pray) · 5 DETAIL (paper weight, binding, lays flat, ribbon) · 6 SIZE (next to a Bible, in hands) · 7 WHO (mum, small group, new believer, pastor) · 8 GIFT (gift-ready packaging + blessing insert) · 9 CLOSE ("Hope lives here.")

### D. Faith: verse coaster set
1 MAIN (every verse legible) · 2 HOOK (the verses: each coaster with its reference) · 3 LIFE (tea + Bible, morning) · 4 DETAIL (print quality, ceramic, cork base) · 5 SET (verse list with references) · 6 SIZE · 7 USES / WHO · 8 GIFT · 9 CLOSE

### E. Gift set (Decorably model, your original list)
1 MAIN · 2 Opening experience (box lid lifting, contents revealed) · 3 What's in the set · 4 How it works in 3 steps (HOW) · 5 Design choices (all designs side by side) · 6 SIZE · 7 WHO · 8 Ways to use (USES) · 9 CLOSE

Use **E** only for products sold and bought primarily as a gift box. For everyday items, the opening experience wastes slot 2.

## 5. Layout system

- **Headline:** top-left or top-centre, Josefin Sans SemiBold or Regular, Espresso or Terracotta, 2–5 words. Sub-line under it in DM Sans, ≤ 6 words.
- **Callouts:** DM Sans Medium, Espresso, ≤ 4 words each, max 3 per image. Thin Espresso line ending in a dot on the product. Small Honey (core) or Olive (Faith) dot marker.
- **Proof badge:** one per image max, circle, bottom-right. Only real proof (certification, material, tested claim from `product-facts.md`). KeaBabies uses OEKO-TEX + "0–36 months". Our equivalents: "Food-safe glaze", "Cork base", "KJV verse", "120gsm paper", only if true.
- **Background for infographics:** Linen, or a soft Sand circle behind the product (KeaBabies uses soft circles behind cut-outs; ours are Sand, never pink/blue).
- **Lifestyle:** full-bleed, text only on naturally clean areas (wall, table, sky), or a Linen card.
- **Bottom band (CLOSE only):** Linen or Terracotta band, tagline centred, logo.
- **Small decorative doodles:** KeaBabies uses line-art animals. ilohaus option: a single thin Espresso line sprig (olive branch for Faith, coffee steam / small leaf for core). Max one per image, never on MAIN.

## 6. Mood words for prompts

Core: *candid, lived-in home, golden hour sun through a window, long soft shadows, warm haze, friends or family mid-moment, snacks and drinks on the table, woven rattan placemat, crumpled linen, worn wood grain, condensation on the glass, cozy, terracotta and honey tones*

Faith: *quiet morning devotion, open journal, soft window light, Bible beside, tea, knit throw, candle, olive branch sprig, peaceful, hopeful, warm neutrals*

Never: *minimalist, studio, clean, empty table, catalogue, cold, blue, neon, pink pastel, glossy, dramatic, luxury marble*

## 7. Planning sheet (fill per product before generating)

Save as `ilohaus-product-library/<product>/listing-plan.md`:

```
Product:
Line: core | faith
Sequence: A | B | C | D | E | custom
Top 3 review complaints / objections:
Top 3 reasons people buy (reviews + SQP):

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | | — | — | white |
| 2 | | | | | |
...
| 9 | CLOSE | | Joy/Hope lives here. | logo | |
```

### Which slots get made
**Where the work comes from:** the weekly Creative Queue (`creative-queue-YYYY-MM-DD.xlsx`, Tuesdays) picks the ASIN and, on its "3 Creative Brief" tab, which images to rebuild. This plan is the standing design for each slot. If the brief asks for an image this plan doesn't cover, the brief wins: add or update the row here. Work status is tracked in `ilohaus-work-log.xlsx`, not in this file.

Creative Brief → slot code: Hero = MAIN · Proof-of-claim = HOOK or DETAIL · In-room = LIFE · What's in the box = SET · Scale = SIZE · Gift = GIFT.

## 8. After it goes live

- Check unit session percentage 4–6 weeks before vs after (same season if possible).
- Test only one change at a time with Manage Your Experiments: main image first, then slot 2.
- Record what won in the product's `visual-identity.md` → "Rules learned from feedback".

## Changelog
- 2026-10-21: Pointer to 11-reference-brands.md added.
- 2026-10-21: LIFE and mood words changed to lived-in (Nook Theory reference); "clean/minimalist" moved to Never.
- 2026-10-20: Slot 2 defined as the second main image (§2a): search carousel + Amazon auto-swapping gallery images in search. Based on 83 KeaBabies listings.
- 2026-10-20: Slots to build come from the Creative Queue's Creative Brief; status lives in the work log. Added brief → slot code mapping.
- 2026-10-19: Rewritten as full listing guide. Studied KeaBabies bibs + wrap listings; added image library, 5 sequences, slot rules, planning sheet.
- 2026-10-19: Created. Sequence from Decorably model.
