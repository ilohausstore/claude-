# 06 — Faith collection ("Hope lives here.")

Mandatory reading for any Faith product. Approval needed to change this file.

## What Faith is

A collection inside ilohaus for scripture-forward products: journals, notebooks, verse coasters, faith gifts. Brand Store page name: **Faith**. Tagline: **Hope lives here.** Accent: **Olive #6E7550.** Never Honey.

## Scripture rules

- **Translations: KJV or WEB (World English Bible) only.** Both are public domain in the US. NIV, ESV, NLT are copyrighted and need publisher permission for merchandise. Don't use any other translation without written permission on file.
- Always print the reference, e.g. "Philippians 4:4". Translation in small text (KJV / WEB).
- Never shorten a verse in a way that changes its meaning.
- Choose hopeful, encouraging verses. Avoid judgement or warning passages.
- Check every verse word-for-word against the source text, twice. AI must state: "Verse checked against [translation] source: [text]".
- **Never let an image model render verse text.** Overlay the exact text from the product's artwork file.

## Starter verses

| Reference | Theme | Best for |
|---|---|---|
| Philippians 4:4 | Rejoice always | Coasters, journal covers |
| Psalm 118:24 | This is the day | Mugs, morning products |
| Lamentations 3:22–23 | New mercies every morning | Journals, devotionals |
| Proverbs 17:22 | A joyful heart | Gifts |
| Romans 15:13 | God of hope | Notebooks, cards |
| Nehemiah 8:10 | Joy of the Lord is strength | Coasters, wall decor |
| Jeremiah 29:11 | Plans and hope | Graduation and new-start gifts |

## Visual direction

- Scenes: open journal, Bible nearby, morning light by a window, a cup of tea, a pen mid-write, a quiet devotion corner.
- The verse is the hero. Show it clearly in at least one close-up.
- Olive for banners and verse labels. Verse text in Espresso, Josefin Sans Light Italic, set large.
- Don't: dramatic church imagery, crosses as decoration, stained glass, glowing light rays, hands raised in worship stock shots.

## Voice

A warm friend who prays for you. Encouraging, never pressuring, shaming or arguing.

- Do: "Start each day with a reminder that His mercies are new."
- Don't: "Every Christian NEEDS this journal."

## Channel notes

- A+: verse shown on product in banner; one module on the meaning behind the verse.
- Inserts: short blessing + the verse on the product.
- Social end card: logo + "Hope lives here."; encouraging hooks, no hard sell.
- Customer emails can close with a short blessing.

## Changelog
- 2026-10-19: Created from Brand Guidelines doc.
