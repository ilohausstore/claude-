# 04 — Source audit

Where every brand rule came from, and what's still missing. Update when a source changes.

## Sources

| Source | Location | Date | Status |
|---|---|---|---|
| ilohaus Brand Guidelines (master) | Claude Doc: https://claude.ai/code/artifact/577058d4-0c08-4351-a804-96f3f5e13717 | 16–19 Oct 2026 | Current. The repo .md files are derived from it |
| Logo | `references/logo/` | Aug 2023 box print file | Vector extracted 2026-10-20 |
| Coaster box artwork | `01-terrazzo-coasters/references/_all-variants/` + originals in OneDrive | Aug 2023 | Legacy design: old tagline, condensed font, 'Handcrafted' claim (see below) |
| Palette swatch image | `references/palette/` | — | Missing in repo. Export from the Brand Guidelines doc |
| Kevan Soh repository model | Notion: Mastermind Notes (Sep 2026), section 6 | Sep 2026 | Reference only |
| Decorably listing image sequence | Notion: Mastermind Notes, section 6 | Sep 2026 | Used as template for `08` |

## If sources conflict

The Brand Guidelines doc wins over this repo. If you find a mismatch, flag it to Sharon; don't silently pick one.

## Gaps to close

- [x] Logo as SVG + Espresso/Linen PNGs (2026-10-20)
- [ ] "FAITH" collection lockup file
- [ ] Palette swatch PNG → `references/palette/`
- [ ] 3–5 approved "this is on-brand" reference images per line → `references/approved/`
- [ ] Current live listing images per ASIN (for before/after) → each product's `references/`

## Packaging vs brand guidelines (fix at next box reprint)
- Box tagline "Redesigning your home the joyful way" → replace with "Joy lives here."
- Box fonts (condensed sans, "WE THINK YOU'VE GOT GREAT TASTE!") are not Josefin Sans / DM Sans
- Box says **"Handcrafted"**. The coasters are machine-made with a digital print (reviews say so). Confirm with supplier or drop the word. Do not repeat "handcrafted" in listings or ads until confirmed
- Box is printed in English + French (for Canada); keep both

## Changelog
- 2026-10-20: Logo found and extracted; packaging gaps listed.
- 2026-10-19: Created.
