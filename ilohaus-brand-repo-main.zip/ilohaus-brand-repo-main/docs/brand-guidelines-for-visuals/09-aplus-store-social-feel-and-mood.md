# 09 — A+, Brand Store and social: feel and mood

Same look as the listings: read `11-reference-brands.md` §1–4 first (constants, the three settings, coherence check). This file only adds what is specific to each surface.

## A+ content

Order: **emotion first, proof second, choice last.**

| Module | Core line | Faith |
|---|---|---|
| 1. Hero banner | Lifestyle in the product's setting (A or B) + "Joy lives here." on a Linen card | Setting C, product with verse visible + "Hope lives here." |
| 2–4. Proof modules | One benefit each, reusing the listing's infographic style (callouts, big numbers), ≤ 15 words | One module on the meaning behind the verse; one on paper/binding |
| 5. Moment module | Second lifestyle crop from the same shoot as the listing | Gift exchange or quiet devotion |
| 6. Comparison chart | Other ilohaus core products only, Linen background, product on Sand card | Other Faith products only |
| Brand Story | ilohaus purpose: joy in everyday homes, cards from settings A, B, C | Same brand story; Faith shown as where we're growing |

- Reuse the listing's photos and headlines where they fit. A shopper who scrolls from the gallery into A+ should see the same home continue, not a new design.
- Never mix core and Faith products in one comparison chart.

## Brand Store

- **Home page:** hero banner from setting A + "Joy lives here."; below it, tiles by moment ("Hosting", "Family meals", "Quiet mornings") rather than by product type.
- **Faith page:** setting C hero + "Hope lives here." + ILOHAUS ✝ FAITH lockup. Olive accents on this page only.
- **Product tiles:** Linen background, product on a Sand card, label in Josefin Sans Regular uppercase. Same card radius as the listing text cards.
- Banner crops come from the same shoots as the listings (`11` §3: shoot once, use three times).

## Social (TikTok / Instagram / Reels)

- Vertical 9:16, safe zones respected (no text in the bottom 20% or right edge).
- Same three settings and the same light as the listings.
- First 2 seconds: a moment, not the product on white (pouring coffee, opening a journal, water soaking into a coaster).
- End card: logo + tagline for the line, Linen background.
- Captions: encouraging, conversational, one question. No hard sell.
- AI video: product must match references in every frame; check for warping of edges and printed text.

## Changelog
- 2026-10-21: Aligned with `11` (one ilohaus look): settings A/B/C, reuse of listing shoots, store tiles by moment, A+ order emotion → proof → choice.
- 2026-10-19: Created from Brand Guidelines doc.
