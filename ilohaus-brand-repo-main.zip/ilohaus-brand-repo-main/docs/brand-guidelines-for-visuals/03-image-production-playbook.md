# 03 — Image production playbook

How to make any ilohaus image (AI-generated, edited photo or composite). Read before every image task.

## The one rule

**Show joy happening in real homes, not products floating in a studio.** (Exception: Amazon main image.)

## Tool stack (who does what)

| Tool | Job | Never |
|---|---|---|
| Claude (repo connected) | Plan, write prompts, QC against this checklist, save rules | Final images |
| Gemini, model Nano Banana Pro (gemini.google.com, signed in as ilohaus.store@gmail.com on the family AI Pro plan) | Scenes and lifestyle, with 2–3 reference photos of the exact variant uploaded; new chat per product; 2K output | Text, verses, logo, main image |
| Canva Pro Background Remover (Sharon's account) | Main image from a real photo (white #FFFFFF, 2000×2000); product cut-outs; swapping the real product into an AI scene when the AI drifts | Scenes from scratch |
| Canva (Brand Kit + slot templates) | Every headline, callout, badge, verse and logo; final export | Generating products |

Prompts Claude writes for image tools contain **no text to render**. Text is added in Canva.

## Before generating

1. Read the product's `product-facts.md`, `visual-identity.md`, `asset-evidence.md`.
2. Open every file in the product's `references/`. Write down: exact shape, glaze/finish, colour, pattern, any printed text, set count, size relative to a hand or mug.
3. Confirm the line (core or Faith) and the accent colour that follows.
4. Write the image plan: purpose of the image, one message, scene, props, text overlay, accent colour.

## Photography and scene style

**Lived-in, not staged.** Reference: Nook Theory (Amazon, Oct 2026). Their lifestyle images feel warm because something is *happening*: people mid-moment, food on the table, a slightly full frame. A clean table with one drink and lots of empty space reads as a catalogue, not a home.

| Do | Don't |
|---|---|
| Something happening: friends sharing snacks, a family breakfast, someone reading with tea | One product + one drink on an empty table |
| Fill the frame: 3–5 everyday items around the product (open book, bowl of fruit, cookies on a plate, a candle, a phone face down) | Big areas of empty wall or table |
| Low golden-hour sun through a window, long soft shadows, a little haze or glow | Even, flat, bright daylight with no shadows |
| Textures: woven rattan placemat, crumpled linen, knit throw, worn wood with grain | Brand-new, spotless, perfectly ironed surfaces |
| Small imperfections: a crumb, a folded napkin, a half-drunk cup, condensation on the glass | Everything lined up and centred |
| People, or at least two hands or a lap/sleeve in frame, cropped naturally; faces optional | A single disembodied hand reaching in |
| Camera close (product fills about 25–40% of the frame), slight angle, shallow depth of field | Wide shot of the whole table and wall |
| Warm grade: creamy highlights, honey and terracotta tones | Cool white walls, grey shadows |
| Faith: open journal, Bible nearby, soft light | Dramatic church imagery, crosses as decoration |

**Settings:** every lifestyle image is set in one of the three ilohaus settings (A living room, B kitchen table, C morning window) in `11-reference-brands.md` §2, with light from the left. Name the setting in the image plan.

Prompt add-on (paste at the end of every LIFE/USES/GIFT prompt): *candid lifestyle photo, lived-in home, golden hour sunlight through a window, warm cozy atmosphere, soft haze, natural clutter, shallow depth of field, editorial home magazine style, not a studio, not minimalist*.

## Product accuracy (where AI fails)

- The product must match the references exactly: shape, edge, glaze, pattern, colour. If the model drifts, composite the real product photo instead of re-prompting endlessly.
- **Printed text and verses must never be AI-generated.** Generate the scene with a blank product, then place the real artwork/verse as an overlay from the product's references.
- Correct scale: a coaster is ~10cm; it sits under a mug, it is not mug-sized. Check against `product-facts.md` dimensions.
- Correct set count: if the set has 4, show 4 (or a clearly partial view).
- Hands: check finger count, nails, natural grip.

## Text overlays

- One message per image. Headline ≤ 6 words, max 3 short callouts.
- Fonts and sizes per `02-visual-design-system.md`.
- Text sits on clean Linen/Sand space or a Linen card, never over busy texture.
- Logo: composite the real file, bottom or top corner, respecting clear space. Not on the main image.

## Image specs

| Use | Size | Format |
|---|---|---|
| Amazon listing image | 2000 × 2000 px | JPG, sRGB, < 10MB |
| A+ standard module | 970 × 600 px (check module) | JPG/PNG |
| A+ premium / Brand Story | per module spec | JPG/PNG |
| Brand Store hero | 3000 × 600 px (desktop) | JPG |
| TikTok / Reels | 1080 × 1920 px | JPG/MP4 |

## Quality check (run on every image before handing over)

- [ ] Product matches references: shape, finish, colour, pattern, count, scale
- [ ] Correct line: core = Honey + "Joy lives here." / Faith = Olive + "Hope lives here."
- [ ] No scripture on core-line products
- [ ] Palette only, accent under 10%, **no blue** (check lighting cast too)
- [ ] Josefin Sans + DM Sans only; nothing thin below 24px; readable on a phone
- [ ] Any verse is KJV/WEB, reference shown, checked word-for-word
- [ ] Logo is the real file, undistorted, clear space respected
- [ ] Photo feels warm, real and naturally lit
- [ ] Hands, edges, text artefacts checked at 100% zoom
- [ ] Copy on image is encouraging, not preachy or salesy
- [ ] Amazon main image: pure white, no text, no props, product ~85% of frame

Report each check as pass/fail in the hand-over note.

## Changelog
- 2026-10-21: Default scene kit replaced by the three ilohaus settings (11 §2) for cross-surface coherence.
- 2026-10-21: Photography rewritten to "lived-in, not staged" after the first LIFE test read too clean (Nook Theory as reference). New default scene kit and prompt add-on.
- 2026-10-20: ChatGPT removed; Gemini (Nano Banana Pro) is the only image tool.
- 2026-10-20: Photoroom replaced by Canva Pro Background Remover.
- 2026-10-20: Added tool stack.
- 2026-10-19: Created.
