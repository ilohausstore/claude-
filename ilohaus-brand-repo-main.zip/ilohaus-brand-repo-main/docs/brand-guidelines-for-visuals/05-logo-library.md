# 05 — Logo library

All logo files live in `references/logo/`. **AI must never generate, retype or redraw the logo.** It composites these files onto finished images.

## Files

**The ilohaus logo has no frame.** The thin rectangle frame is for packaging only. Vector files were extracted from the coaster box print file (`Print ready.pdf`, Aug 2023), so they scale to any size.

| File | Use |
|---|---|
| `ilohaus-logo-espresso.svg` / `.png` | **Master logo.** On Linen, Sand or light photos (PNG transparent, 2400 px wide) |
| `ilohaus-logo-linen.svg` / `.png` | On Terracotta, Espresso or dark photos |
| `ilohaus-logo-faith-olive`, `-espresso`, `-linen` (.svg / .png) | **Faith lockup**: ILOHAUS ✝ FAITH. Thin, tall Latin cross as the divider, FAITH smaller and centred, built in the logo's own letterforms. Olive = default on light backgrounds; Espresso = one-colour print; Linen = on dark. Faith products only |
| `ilohaus-logo-ads-1200x200-white.png` | Display ads logo (2× of Amazon's 600 × 100 minimum), Espresso on white, no frame |
| `ilohaus-logo-packaging-frame-*.svg` / `.png` | Logo in the thin frame. **Packaging only** (box, inserts, labels) |
| `ilohaus-logo-with-tagline*.svg` / `.png` | Framed logo + old tagline "Redesigning your home the joyful way". **Packaging only, legacy.** New work uses "Joy lives here." set separately in Josefin Sans |

The wordmark is uppercase "ILOHAUS". In body copy the brand name stays lowercase "ilohaus".

## Placement

- Clear space = height of the logo's "H" on all sides.
- Minimum width on a 2000px listing image: ~240px.
- Preferred spots: bottom-centre on lifestyle and A+ banners; top-left on infographic images. Never on the Amazon main image.
- Tagline under or beside, set in Josefin Sans Regular, Terracotta or Espresso.

## Don't

- Stretch, rotate, outline, shadow, gradient
- Recolour in Honey, Olive, or anything off-palette
- Add a cross, dove or icon to the master logo (the Faith lockup's thin cross divider is the only exception)
- Place over busy texture without a Linen card behind it

## Changelog
- 2026-10-21: Master logo is frameless (per Sharon); frame is packaging only. Frameless master, linen and ads files made; framed files renamed packaging-frame-*. Faith lockup: ILOHAUS ✝ FAITH (thin cross divider) in Olive, logo letterforms (sub-brand rule: same typography, colour sets it apart).
- 2026-10-20: Vector logo extracted from box print file; Espresso, Linen and ads versions added.
- 2026-10-19: Created. Logo files outstanding.
