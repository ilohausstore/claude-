# 02 — Visual design system

Approval needed to change this file.

## Colour palette

Earthy, down-to-earth: terracotta, sand and warm browns. Three core colours carry every design. Honey brings the joy on the core line; Olive marks Faith. **No blues. Ever.**

| Tier | Colour | Hex | RGB | Role |
|---|---|---|---|---|
| Core | Linen | `#F3ECE2` | 243, 236, 226 | Main background, both lines |
| Core | Terracotta | `#B5603F` | 181, 96, 63 | Signature colour: headlines, taglines, buttons |
| Core | Espresso | `#3E2C23` | 62, 44, 35 | Logo, body text (replaces black) |
| Secondary | Sand | `#D8C3A5` | 216, 195, 165 | Cards and soft backgrounds, both lines |
| Secondary | Honey | `#D9A441` | 217, 164, 65 | Joy accent: badges, callouts (**core line only**) |
| Secondary | Olive | `#6E7550` | 110, 117, 80 | Faith accent: banners, verse labels (**Faith only**) |

### Proportion
About **60% Linen or Sand, 30% Terracotta and Espresso, 10% Honey or Olive.**

### Colour rules
- Never Honey and Olive in the same design.
- Text is Espresso, never pure black. Reversed text is Linen, never pure white (except Amazon main image background).
- No gradients. Flat colour fields only.
- Large areas of Honey look cheap on Amazon. Accent only.
- Lighting in photos stays warm. A cold blue cast in a photo breaks the palette even if no blue is "used".
- **"No blue" is for what we design**: backgrounds, props, text, badges, graphics. **Never recolour the product.** If a product print has blue or teal (e.g. terrazzo chips), reproduce it exactly; colour accuracy beats palette purity.

## Typography

Headlines echo the logo: a thin, geometric sans with clean lines. Both fonts are free on Google Fonts.

| Use | Typeface | Style |
|---|---|---|
| Short headlines, Brand Store banners | Josefin Sans | Light, UPPERCASE, letter-spacing +10% |
| Taglines | Josefin Sans | Regular, sentence case: "Joy lives here." |
| Verses (Faith only) | Josefin Sans | Light Italic, set large; reference in DM Sans |
| Body copy, listing callouts, captions | DM Sans | Regular, Medium for emphasis |

### Type rules
- **Never Josefin Sans Thin or Light below 24px or on Amazon thumbnails.** Thin strokes disappear on mobile; step up to Regular or SemiBold.
- Uppercase only for headlines of five words or fewer.
- No more than two typefaces in one design.
- On listing images, callout text must be readable at phone size: minimum ~40px on a 2000px image.

## Logo

Keep the existing ilohaus logo: thin geometric uppercase wordmark, **no frame** (the rectangle frame is packaging only). **It is artwork. Never retype it in a font, redraw it, or let an image model generate it.** Composite the real file from `references/logo/` onto the finished image.

- Clear space around the logo = height of the "H" in the logo.
- Espresso on light backgrounds, Linen on dark. No gradients, shadows or outlines.
- Never stretch, rotate, or recolour in Honey or Olive.
- Tagline sits under or beside the logo, never inside it.
- "Joy lives here." pairs with the core line. "Hope lives here." pairs only with Faith.
- Faith uses the Faith lockup: **ILOHAUS ✝ FAITH** (thin, tall cross as divider; FAITH smaller, in the logo's own letterforms, never another font), Olive by default (`ilohaus-logo-faith-*`). Same typography as the parent, colour sets it apart. No script, no other icon. The cross lives only in this lockup, never on the core-line logo.

Logo files: vector SVG in `references/logo/` (see `05-logo-library.md`).

## Changelog
- 2026-10-21: Logo is frameless (frame = packaging only); Faith lockup = ILOHAUS ✝ FAITH in Olive (thin cross divider, approved by Sharon), logo letterforms.
- 2026-10-20: No-blue rule scoped to design elements; product colours never altered.
- 2026-10-19: Created from Brand Guidelines doc.
