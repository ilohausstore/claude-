# 10 — Ad creative: Display ads (formerly Sponsored Display) and Sponsored Brands

Read with `02` (palette, fonts), `03` (production + QC) and `07` (voice). Approval needed to change this file.

Sources checked 20 Oct 2026: Amazon Ads API / help specs as summarised by gloriads.com (Oct 2026), Amazon Sponsored Ads creative guidelines (via stellarising.com), canopymanagement.com (2026 rename), live amazon.com searches for KeaBabies and Nook Theory. **Amazon changes specs often. If an upload is rejected, check the error against this file and update it.**

---

## 1. What actually shows, and where

| Placement | What the shopper sees | Which creative decides it |
|---|---|---|
| Product detail page, under the buy box (Display ads, contextual/product targeting) | **Your main image** + title + stars + price + Prime | **The listing main image (slot 1).** No custom image is used here. Observed 20 Oct 2026: a competitor's ocean-print coaster ad sits under the buy box on our TZM-001-001 page, showing only their main image |
| Off Amazon and Amazon homepage (Display ads, audience targeting) | Custom lifestyle image + headline + logo, or auto ad | **Custom image, headline, logo (this file)** |
| Top of search (Sponsored Brands) | Logo + headline + 3 products, or custom image + product, or video | Logo, headline, custom image, video |

**So the first ad creative to get right is the main image.** A main image that reads clearly at 160 px wide (thumbnail size in the ad slot) is worth more than any custom image.

### Main image test for ads
- Shrink to 160 × 160 px. Can you still tell what the product is, see the print, and see the holder or set count?
- Full set fanned or stacked so the **count** is visible (6 coasters, 4 bowls).
- No wasted white space. Product fills about 85% of the frame.

---

## 2. Display ads: custom creative specs

| Element | Spec |
|---|---|
| **Custom image** | Minimum **1200 × 628 px**, JPG/PNG/GIF, **max 5 MB**. Amazon also crops a **square**, minimum **628 × 628 px**, from it |
| **Our working size** | Design at **2400 × 1256 px** (2×). Keep everything important inside the **centre square (1256 × 1256)** so the square crop still works |
| **Headline** | **Max 50 characters.** No emojis. **No `< > # ^ !`**. No more than half in capitals |
| **Logo** | Minimum **600 × 100 px**, JPG/PNG, max 1 MB. Use the horizontal wordmark on **white**, filling the space |
| **Video** | 16:9, 1920 × 1080 or larger, max 500 MB, **15 seconds**, one product per video, H.264, AAC/PCM audio ≥ 192 kbps |

### Custom image: what gets rejected
- Product cut out on a plain or white background
- A logo on its own
- Any image already used on the product page (no reusing listing images)
- **Added text of any kind.** Text printed on the product or packaging is fine. This means **verses printed on a Faith product are allowed**, but no headlines, callouts or badges on the image
- Black bars (letterbox or pillarbox)
- Crowded, poorly cropped or low-resolution images

The headline does the talking. The image only shows the moment.

---

## 3. Sponsored Brands: custom creative specs

| Element | Spec |
|---|---|
| Custom image | 1200 × 628 px (design at 2400 × 1256), under 1 MB, PNG/JPG/GIF. Same "no added text, no plain-background cut-out" rules |
| Logo | 400 × 400 px, under 1 MB |
| Video | 1920 × 1080 recommended; 6–45 s, aim for **15–30 s**; key message in the first 3 seconds; captions on (most viewers have sound off); no fade-in from black |

---

## 4. What we learned from KeaBabies and Nook Theory (live, 20 Oct 2026)

| Brand | Search | What they ran | Take for ilohaus |
|---|---|---|---|
| KeaBabies | "baby bibs" | Sponsored Brands product collection. Headline: **"Organic baby bandana bibs"**. Three colourways of the same 8-pack | Headline = the shopper's search phrase plus one differentiator. Not a slogan. Show 3 colourways of the hero product, not 3 different products |
| Nook Theory | "nook theory" | Same format. Headline: **"Reusable bamboo plates"**. Three prints of the same plate set | Same rule. Nook Theory sells terrazzo-print bamboo plates at $19.96, a **direct competitor** to our kids plates |
| Nook Theory | "bamboo kids plates" | Custom image: plates mid-fall onto a floor, with the question **"Unbreakable? Shatterproof?"** on a yellow panel | They lead with the drop-test objection. **Don't copy this for our bowls**: our reviews report breakage. Note the text is on the image; that risks rejection under current rules. Put questions like this in the headline instead |
| Mckanti | "absorbent coasters" | Product collection, headline **"8 pack coaster with holder"** | Coaster category leader leads with **count + holder**. Our equivalent: "Set of 6 coasters with gold holder" |

**Pattern:** the category winners write boring, literal headlines that match the search. Brand voice ("Joy lives here.") goes in the logo lock-up and the image mood, not in the headline.

---

## 5. Headline rules for ilohaus

- ≤ 50 characters, sentence case, **no exclamation marks** (Amazon rejects `!`)
- Formula: **[what it is] + [one proof or differentiator]**
- Claims only from the product's `product-facts.md`. Nothing under "Do NOT claim"
- No price, discount, "best seller", "#1" or time limits
- Faith: no preaching, no pressure. The verse can be the hook

| Product | Good headlines (characters) |
|---|---|
| Terrazzo coasters | Terrazzo coasters that soak up every drop (41) · Set of 6 coasters with gold holder (34) |
| Marble coasters | Absorbent coasters, gift box included (37) |
| Kids bamboo bowls | Lightweight bamboo bowls for little hands (41) |
| Kids bamboo plates | Bamboo kids plates. Dishwasher safe (35) |
| Faith scripture coasters | Six Bible verses for your coffee table (38) · A daily reminder of His word (28) |
| Faith notebook | KJV verse on every page of your journal (39). Use only once interior KJV pages are live |

---

## 6. Custom image: scene rules

- **One moment, one product, no text.** The product must be recognisable at 300 px wide
- Product in the **centre square**; scene can extend left and right for the landscape crop
- Use the approved scene style from the product's `visual-identity.md` (terrazzo: blush plinth, pampas, gold spoon, daylight)
- Hands in frame where it makes sense: pouring, writing, setting a table
- Palette and lighting per `02`. **No blue**
- Different from every listing image. Make it fresh, from the same shoot or a new AI scene, never a crop of a listing image
- Faith: the verse printed on the product must be legible and correct (overlay the real artwork; never AI-rendered)

### Per product: first custom images to make
| Product | Scene |
|---|---|
| TZM-001-001 terrazzo | Hand pouring espresso over an iced latte on the coaster, holder beside (from ref-07) |
| Marble coasters | Two friends' glasses on coasters on a coffee table, gift box half-open in the background |
| Kids bowls/plates | Child's hands reaching for cereal at a family breakfast table. Bowl on the table, never dropped or thrown |
| Faith scripture coasters | Morning tea on the coaster beside an open Bible, verse readable |
| Faith notebook | Open notebook on a church pew or kitchen table, pen in hand, KJV header page visible |

---

## 7. Production steps

1. Claude: "Make a Display ad brief for [product/SKU]: 3 headlines and 1 custom image scene, following 10-ads."
2. Make the scene in the image tool (no text in the prompt), at least 2400 × 1256 px
3. Canva: crop/scale to 2400 × 1256, check the centre-square crop, **add no text**. Export JPG < 5 MB (< 1 MB for Sponsored Brands)
4. Logo: export the wordmark on white at 1200 × 200 px (2× of 600 × 100)
5. Claude QC: run `03` checklist plus the checks below
6. Hand over to Sharon in Lark. VAs don't upload or launch ads

### Ad QC (add to the `03` checklist)
- [ ] No added text on the image (packaging/product print only)
- [ ] Centre-square crop still shows the product clearly
- [ ] Not a reuse of any listing image
- [ ] Headline ≤ 50 characters, no `!`, every claim in `product-facts.md`
- [ ] Image ≥ 1200 × 628, file under the size limit
- [ ] Main image passes the 160 px test

## Changelog
- 2026-10-20: Created. Specs per Amazon Ads docs (Oct 2026 summaries); examples from live KeaBabies, Nook Theory and Mckanti ads.
