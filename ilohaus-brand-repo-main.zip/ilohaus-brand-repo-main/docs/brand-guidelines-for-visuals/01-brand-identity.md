# 01 — Brand identity

Source: ilohaus Brand Guidelines (Claude Doc, 16 Oct 2026). Approval needed to change this file.

## Essence

ilohaus exists to bring small moments of joy into everyday homes, and through the Faith collection, to bring hope and encouragement rooted in Christ.

| Element | Line |
|---|---|
| Brand name | ilohaus (always lowercase in copy) |
| Master tagline | Joy lives here. |
| Faith collection | Faith |
| Faith tagline | Hope lives here. |
| Promise | Everyday pieces that make home feel joyful, and remind you there is always hope. |

The two taglines share one structure on purpose. "Joy lives here." is the brand. "Hope lives here." is where the brand is growing.

## Architecture: one brand, two lines

Faith is a collection inside ilohaus, not a separate brand.

| | ilohaus (core line) | Faith collection |
|---|---|---|
| Tagline | Joy lives here. | Hope lives here. |
| Audience | Anyone who wants a joyful, warm home | Christian buyers and gift-givers |
| Products | Coasters, bowls, plates, home decor | Notebooks, journals, verse coasters, faith gifts |
| Scripture on product | **Never** | Yes, the hero of the design |
| Brand Store | Main pages | Its own page named "Faith" |
| Accent colour | Honey | Olive |

## Rules

- Keep scripture off core-line products. Mixing them confuses both audiences.
- Every Faith product still carries the ilohaus name, so the collection builds the master brand.
- New launches lean toward Faith over time. That is how the brand moves toward faith without abandoning the core business.

## How to decide which line a product belongs to

Check `product-facts.md` → field `line:`. If it's missing, stop and ask. Never guess.

## Changelog
- 2026-10-19: Created from Brand Guidelines doc.
