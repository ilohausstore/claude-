# 11 — One ilohaus look (and the reference brands behind it)

Listings, A+ and the Brand Store must look like **one brand in one home**. A shopper who sees listing image 3, the A+ hero and the Store banner side by side should feel they are in the same house, in the same light, with the same voice.

Six reference brands informed this look (table at the end). **They feed one system; they are never mixed per image.** If a reference idea breaks a rule below, the rule wins.

## 1. The constants (identical on every surface)

| Element | The ilohaus way |
|---|---|
| **The home** | Every lifestyle image happens in one of three recurring settings (§2). Same furniture, same props, same light |
| **Light** | Low golden side light from a window, long soft shadows, a little warm haze. Never flat overhead or cold light |
| **Colour grade** | Creamy highlights, honey and terracotta mid-tones, warm wood. Palette from `02`: about 60% Linen/Sand, 30% Terracotta/Espresso, 10% accent |
| **People** | Hands, laps, sleeves; faces optional, never looking at the camera. Real moments, not poses |
| **Text block** | Headline in Josefin Sans, sub-line in DM Sans, on clean space or a Linen card with rounded corners (radius 24 px at 2000 px wide; scale for other sizes). Same corner, same margin (6% of width) everywhere |
| **Callouts** | Thin Espresso line ending in a dot on the product; label in DM Sans Medium; max 3 |
| **Numbers** | Big Josefin Sans figure + small DM Sans caption ("4 in · 6 coasters · 1 holder") |
| **Badge** | One round badge, Sand fill, Espresso text, bottom-right. Max one per image or module |
| **Headline voice** | Direct, two-beat, full stops, ≤ 6 words: "No rings. No slides." Never hype words or exclamation marks |
| **Logo** | Core: ILOHAUS. Faith: ILOHAUS ✝ FAITH. Same placement rules (`05`) |
| **Accent** | Honey for core, Olive for Faith. Never both in one design |

## 2. The three ilohaus settings

Shoot or generate every lifestyle image in one of these. Reusing them is what makes 30 listings, the A+ pages and the Store feel like one home.

| Setting | Use for | Fixed elements |
|---|---|---|
| **A. The living room** | Coasters, hosting, friends | Warm wood coffee table with visible grain, cream linen sofa, woven rattan tray, knit throw, dried flowers in a ceramic vase, afternoon sun from the left |
| **B. The kitchen table** | Bowls, plates, family meals, kids | Oak dining table, linen runner in Sand, terracotta-toned ceramics, a fruit bowl, morning sun from the left |
| **C. The morning window** | Faith journals, notebooks, verse coasters | Small wooden desk or window seat, open Bible, mug of tea, candle, olive sprig in a bud vase, early soft light from the left |

Light always comes from the **left**, so images sit together in any grid. Write the setting letter in every image plan.

## 3. What each surface does (same look, different job)

| Surface | Job | Mix |
|---|---|---|
| **Listing images** (`08`) | Answer buyer questions fast; win the click and the add-to-cart | About 4 lifestyle, 4 infographic, 1 closing brand image, alternating |
| **A+ content** (`09`) | Deepen the feeling and remove the last doubts | Emotion first (hero in the setting), then 2–3 proof modules, then comparison within the line |
| **Brand Store** (`09`) | Show the ilohaus home; browse by moment | Mostly lifestyle; product tiles on Linen; one Faith page |

**Shoot once, use three times.** Each new lifestyle scene is planned with three crops: square (listing), wide 970 × 600 (A+), and extra-wide banner (Store). Leave room on the left or right for the text block.

## 4. Coherence check (before anything goes live)

- [ ] Put the new image next to two live ilohaus images (listing, A+ or Store). Same light direction, same grade, same type, same card style?
- [ ] Cover the logo. Could a shopper still tell it's ilohaus?
- [ ] Setting A, B or C named in the plan?
- [ ] Headline passes the voice rule?
- [ ] No reference brand's look copied (their colours, their layouts, their words)?

## 5. The reference brands (inputs, not styles)

| Brand | Why Sharon likes it | Take | Leave |
|---|---|---|---|
| **Navy Peony** (travel stickers) | Happy emotions | Hands holding and giving the product; the product inside someone's personal world (passport, journal, coffee, suitcase); candid joy | Bright pink and blue backdrops; people posing and smiling at the camera |
| **KeaBabies** (baby) | Real, warm | Real families mid-moment; one message per image; image 2 as the second main image (see `08` §2a); proof badges | Baby-pastel palette; pink and blue |
| **Nook Theory** (plates, bags) | Scandi, warm | Lived-in scenes: full table, food, people, golden sun, rattan and linen textures (see `03`); rounded text labels on a soft card | Kids-tableware brightness; teal labels |
| **Naoki** (matcha) | Clean elegance, luxury | Restraint: few words, lots of space, one fact per image; big numbers with small captions ("3.5 oz · 1 tsp · 50 servings"); fine type, no badges or stickers | Black and dark backgrounds (not our palette) |
| **Highmark Collective** (Christian notebooks and gifts; **direct Faith competitor**) | Clean, direct | Two-beat headlines ("No Bleed-Through. No Distractions." / "Meaningful Enough to Gift."); "different uses" grid with 4 labelled photos; two women exchanging a gift; woman writing at a warm desk; spec icon row for paper | Busy multicolour florals; teal backgrounds; any of their wording (write our own) |
| **Decorably** (planners) | Very technical content | The information: exact dimensions, "choose from 3 layouts", how to display/use, what's included | The design: cyan banners, stacked circle badges, rainbow pastels, too much text per image |

## 6. Faith vs Highmark Collective

Highmark sells Christian notebook sets with bright floral covers. ilohaus Faith competes on **calm and warmth**: earthy palette, KJV verses, setting C, the "ILOHAUS ✝ FAITH" lockup. Borrow their "uses" grid (church · small group · journal · gift) and the gift-exchange moment; never their florals, teal or wording.

## Changelog
- 2026-10-21: Rewritten as "One ilohaus look": constants, three recurring settings, surface roles, coherence check. Reference brands kept as inputs only.
- 2026-10-21: Created from Sharon's six reference brands (Navy Peony, KeaBabies, Nook Theory, Naoki, Highmark Collective, Decorably), studied on Amazon.
