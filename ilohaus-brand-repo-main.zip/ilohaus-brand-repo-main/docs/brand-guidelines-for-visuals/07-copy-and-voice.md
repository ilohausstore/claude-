# 07 — Copy and voice

Applies to image text, listing copy, A+, Brand Store, social captions, inserts and customer emails.

## Personality

ilohaus sounds like **a warm friend who prays for you**, never like a pulpit or a salesperson.

| We are | We are not |
|---|---|
| Joyful | Hyper or gimmicky |
| Warm | Cutesy or saccharine |
| Encouraging | Preachy or guilt-driven |
| Hopeful | Fearful or doom-based |
| Simple | Wordy or salesy |

## Writing rules

- Short sentences. Speak to one person: "you", not "customers".
- Lead with the feeling or moment, then the product detail.
- Faith copy encourages. It never pressures, shames or argues.
- No hype words: "insane", "must-have", "best ever", "premium quality", "perfect gift for everyone".
- Image text: headline ≤ 6 words, callouts ≤ 5 words each.
- Claims only from `product-facts.md`. "Absorbent" only if it's listed and supported.

## Examples

| Context | Do | Don't |
|---|---|---|
| Core product | "A little joy for your morning coffee." | "Best premium ceramic coasters, must-have!" |
| Faith product | "Start each day with a reminder that His mercies are new." | "Every Christian NEEDS this journal." |
| Customer service | "So sorry this arrived chipped. We'll send a new one today." | "Per our policy, please submit a claim." |
| Social caption | "Hope lives here. Who needs this reminder today?" | "Buy now before it's gone!!!" |

## Channel lines

| Channel | Core line | Faith |
|---|---|---|
| Brand Store | Hero: lifestyle shot + "Joy lives here." | "Faith" page hero: journal shot + "Hope lives here." |
| Packaging insert | "Joy lives here. Thank you for bringing us home." | Short blessing + the verse on the product |
| TikTok / Instagram end card | Logo + "Joy lives here." | Logo + "Hope lives here." |
| Customer emails | Warm, first name, short | Can close with a short blessing |

## Amazon compliance (copy on images and in listings)

- No price, discount, "sale", "best seller", "#1", or time-limited claims.
- No competitor names. No unverifiable health or safety claims.
- Gift angles ("a gift for mum") are fine; keep them specific and factual, not "perfect for everyone".

## Changelog
- 2026-10-19: Created from Brand Guidelines doc.
