# Brand guidelines for visuals

The ilohaus brand, split into files the AI reads before every task. Master source: the ilohaus Brand Guidelines Claude Doc (see `04-source-audit.md`).

| File | Read when |
|---|---|
| `01-brand-identity.md` | Every task |
| `02-visual-design-system.md` | Every task (palette, fonts, logo rules) |
| `03-image-production-playbook.md` | Every image task (includes the quality checklist) |
| `04-source-audit.md` | When a rule seems wrong or a source changes |
| `05-logo-library.md` | Any image with the logo |
| `06-faith-collection.md` | Any Faith product (scripture rules) |
| `07-copy-and-voice.md` | Any copy, including text on images |
| `08-listing-images-feel-and-mood.md` | Amazon listing images (9-image sequence) |
| `09-aplus-store-social-feel-and-mood.md` | A+, Brand Store, social |
| `10-ads-display-and-sponsored-brands.md` | Display ads (Sponsored Display) and Sponsored Brands creative: specs, headlines, custom images |
| `11-reference-brands.md` | Any listing, A+ or social image: what we take (and leave) from the six reference brands |

`references/` holds the logo, palette swatch and approved on-brand example images. `archive/` holds retired versions.

**Changes to these files need Sharon or Cheng Zhi's approval.** Every file has a `## Changelog`; add a dated line for each change.
