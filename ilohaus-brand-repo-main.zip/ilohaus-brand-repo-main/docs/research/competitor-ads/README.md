# Competitor research

One folder per competitor brand (e.g. `decorably/`, `<coaster-competitor>/`). Inside each:

- `notes.md`: what they do well, image archetypes, hooks, price point, date checked
- `screenshots/`: small JPGs only (heavy files go to OneDrive)

Refreshes go in dated folders: `refresh-YYYY-MM-DD/`. This is reference for ideas, never to copy layouts or artwork.
