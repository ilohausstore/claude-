# ilohaus-brand-repo

The ilohaus brand repository: brand rules, product facts and AI skills in one place, so every image, piece of copy and video comes out on-brand whoever makes it.

- **AI:** reads `CLAUDE.md` first.
- **People:** read the SOP in Notion: "SOP — ilohaus Brand AI Repository (GitHub + local folder)".

## Where it lives
- GitHub (private): `ilohaus-brand-repo`
- Local copy: `C:\ilohaus-brand-repo` (**never inside OneDrive**)
- Heavy files and final exports: OneDrive `CLAUDE VIBE\ilohaus\`

## Structure
- `docs/brand-guidelines-for-visuals/`: brand rules (01–09)
- `docs/research/`: competitor research
- `ilohaus-product-library/`: one folder per product
- `.claude/skills/`: repeatable tasks
- `output/`, `tmp/`: AI working files, not saved to GitHub
