# ilohaus product library

One numbered folder per product family, ordered by 90-day US sales. To add one: copy `_template/` or ask Claude "create a new product folder for <product>".

**The AI must open the product's `references/` images before creating any product image.**

| # | Folder | Line | Parent ASIN | 90-day US sales | Status |
|---|---|---|---|---|---|
| 01 | `01-terrazzo-coasters` | core | B0BHMRWQSC | $51,347 (64% of US sales) | draft |
| 02 | `02-marble-coasters` | core | B0FWPM9VC7 | $10,315 | draft |
| 03 | `03-kids-bamboo-bowls` | core | B0D5HHMGQF | $5,997 | draft |
| 04 | `04-kids-bamboo-plates` | core | B0DCDVB64W | $5,386 | draft |
| 05 | `05-faith-scripture-coasters` | faith | B0FX3LMB31 | $4,356 | draft |
| 06 | `06-faith-spiral-bible-journal` | faith | B0FC2DC362 | $2,621 | draft · **priority Faith product** |
| 07 | `07-faith-180-day-prayer-journal` | faith | B0GDZWQHXS | $496 | **discontinued** |

Status = draft until reference photos are added and every TBC is resolved.
