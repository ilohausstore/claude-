# Product facts: Christian Scripture Coasters Set of 6 with Holder

Source: live US listing B0F53LZXNT + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: faith
- brand_store_page: Faith
- product_name (listing): Christian Coasters Set of 6 with Holder, Absorbent Ceramic Faith Gift
- short_name (internal): faith-scripture-coasters
- parent_asin: B0FX3LMB31
- child_asins (US, 90-day sales):
  - B0F53LZXNT · SKU COS-BLESSED · 90d US $3,658
  - B0FX2KJMZZ · SKU COS-PSALMS · 90d US $356
  - B0FX2G8TF4 · SKU COS-PROVERBS · 90d US $341
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Six absorbent ceramic coasters, each with a different Bible verse, cork base, holder and gift box.
- set_contents: 6 coasters (6 different verses) + holder + gift box (per A+ comparison chart)
- variations: Blessed, Proverbs, Psalm

## Specs
- dimensions: 4 in (≈10 cm) diameter (TBC for this family)
- weight: TBC
- material: Ceramic with cork backing
- finish: Matte printed
- base: Cork, thick
- care: Hand wash only (see A+ cleaning guide)

## Faith only
- verse(s) on product, exact text: TBC (copy from print artwork)
- reference(s): TBC
- translation: TBC — must be KJV or WEB
- verse checked against source by / date: TBC

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| Absorbs water in about 3–5 seconds | A+ comparison chart — confirm supplier test |
| Cork base, non-slip | A+ |
| Holder + gift box | A+ chart |
| Different verse on each coaster | Reviews |

## Do NOT claim
- Stain-proof
- Dishwasher safe
- Verse translation until confirmed (must be KJV or WEB)

## Buyer
- who buys it: Christian women; gift buyers for housewarming, baptism, church friends, pastors, Mother's Day, Christmas
- top review praise: Beautiful; sturdy, good weight; different verse on each; family reads the scriptures; great gift
- top review complaints (images must pre-empt): None significant yet (63 reviews). Watch for verse errors

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
