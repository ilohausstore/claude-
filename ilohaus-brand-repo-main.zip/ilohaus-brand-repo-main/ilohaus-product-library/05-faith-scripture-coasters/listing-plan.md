# Listing plan: Christian Scripture Coasters Set of 6 with Holder

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: faith (Olive, "Hope lives here.")
- Sequence: D (adjusted from reviews)
- Top objections (reviews): None significant yet (63 reviews). Watch for verse errors
- Top reasons people buy: Beautiful; sturdy, good weight; different verse on each; family reads the scriptures; great gift

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: 6 coasters, verses legible + holder |
| 2 | HOOK | What do they say? | Six verses. Six reminders | Each coaster + its reference | Grid of 6 with references |
| 3 | LIFE | How will it feel? | Hope lives here. | — | Tea, open Bible, morning window light |
| 4 | DETAIL | Quality? | Made to keep | Absorbs in seconds · Cork base · Holder | Macro |
| 5 | SIZE | Fits my mug? | Fits every mug | 4 in / 10 cm | Under mug, hand |
| 6 | EMOTION | Why does it matter? | His word, every cup | — | Couple / friend reading coaster at table |
| 7 | WHO | Who's it for? | For the faithful in your life | Mum · Pastor · Small group · Baptism | Lifestyle + labels |
| 8 | GIFT | Is it gift-ready? | Gift box included | Box · Holder | Box open |
| 9 | CLOSE | ilohaus Faith | Hope lives here. | Logo + FAITH lockup | Lifestyle + Linen band |

**Note:** Only 1 bullet point shows on the live US listing (the other 4 may be missing or suppressed). Check the listing in Seller Central.

## Changelog
- 2026-10-19: Draft plan from listing + reviews. Standing design per slot; the weekly Creative Queue decides which slots get built.
