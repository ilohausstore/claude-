# Christian Scripture Coasters Set of 6 with Holder

- **Line:** faith
- **Parent ASIN:** B0FX3LMB31 (top child B0F53LZXNT)
- **Status:** draft. Facts pulled from live US listing 2026-10-19; photos and TBC fields outstanding
- **US price / rating:** $18.96 · 4.8★ (63), Amazon's Choice
- **90-day US sales:** $4,356

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
