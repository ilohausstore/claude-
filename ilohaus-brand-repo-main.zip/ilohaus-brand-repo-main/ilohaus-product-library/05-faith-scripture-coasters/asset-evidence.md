# Asset evidence: Christian Scripture Coasters Set of 6 with Holder

**Status: no reference photos yet. Do not generate product images until `references/` has at least ref-01 to ref-04.**

## In this repo (references/)
| File | What it shows | Status |
|---|---|---|
| ref-01-front.jpg | Product front, true colour, daylight | Needed |
| ref-02-set-flatlay.jpg | Full set from above (every piece/design) | Needed |
| ref-03-macro.jpg | Texture/print/edge close-up | Needed |
| ref-04-base-or-back.jpg | Base / back / spiral / inside page | Needed |
| ref-05-scale-in-hand.jpg | In hand or with a mug/Bible for scale | Needed |
| ref-06-packaging.jpg | Box, holder, insert | Needed |
| ref-07-artwork.png | Verse/cover print artwork (exact text) | Needed |

## Current live listing images
- Download from Seller Central for B0F53LZXNT → `references/live/` for before/after

## In OneDrive (originals)
| Path | What it is |
|---|---|
| OneDrive\CLAUDE VIBE\ilohaus\products\05-faith-scripture-coasters\raw\ | Original photos |
| OneDrive\CLAUDE VIBE\ilohaus\products\05-faith-scripture-coasters\artwork\ | Print files |

## Detail → evidence
| Detail | Proven by |
|---|---|
| set contents | ref-02 + listing |
| dimensions | supplier spec (TBC) |
| material / care | listing + supplier spec |
| verse text | ref-07 artwork, checked vs KJV/WEB |

## Changelog
- 2026-10-19: Created.
