# Visual identity: Christian Scripture Coasters Set of 6 with Holder

## How the product must look
- shape / silhouette: Round, 4 in, cork base
- colours: Design-specific; verse lettering must be legible
- details that must be visible: Every verse legible with reference; holder; gift box
- details AI usually gets wrong: **Never let AI render verse text.** Overlay from artwork files. Don't add crosses/church imagery

## Accent colour
- faith → Olive. Tagline: "Hope lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: oak/walnut table, linen napkin (Linen/Sand), ceramic mug, small plant, Bible, tea cup, pen
- props never: blue items, glossy marble, clutter, crosses as decoration

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- Only 1 bullet point shows on the live US listing (the other 4 may be missing or suppressed). Check the listing in Seller Central.

## Changelog
- 2026-10-19: Created.
