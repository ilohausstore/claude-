# Visual identity: Bamboo Kids Bowls Set of 4 (20 oz, 6 in)

## How the product must look
- shape / silhouette: Deep round bowl, 6 in, straight-ish walls; pattern on outside
- colours: Per colourway; bright prints. Scenes stay neutral
- details that must be visible: Exact pattern on outside; depth (20 oz is deep); matte texture
- details AI usually gets wrong: Don't show it bouncing or being thrown (drop claims). Don't show it in a microwave. Don't make prints brighter than real

## Accent colour
- core → Honey. Tagline: "Joy lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: oak/walnut table, linen napkin (Linen/Sand), ceramic mug, small plant
- props never: blue items, glossy marble, clutter, any scripture

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- 'Shatter-resistant' copy is fighting the reviews. Use 'lightweight and sturdy' until the drop issue is solved. Microwave ✗ must be visible to avoid returns.

## Changelog
- 2026-10-19: Created.
