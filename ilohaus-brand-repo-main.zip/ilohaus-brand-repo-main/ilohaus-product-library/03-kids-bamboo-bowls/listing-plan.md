# Listing plan: Bamboo Kids Bowls Set of 4 (20 oz, 6 in)

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: core (Honey, "Joy lives here.")
- Sequence: B (adjusted from reviews)
- Top objections (reviews): Broke on first drop / arrived broken (fragile vs 'kids' promise); smaller than expected; colours less vibrant than photos
- Top reasons people buy: Perfect cereal size; cute patterns; durable; easy dishwasher clean

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: 4 bowls, 2 stacked + 2 front |
| 2 | HOOK | Is it safe for my kids? | Safe for little hands | BPA-free · Food grade · Lightweight | Infographic + proof badge |
| 3 | LIFE | How will it feel? | Breakfast, made happy | — | Kid with cereal at family table, morning light |
| 4 | SIZE | Is it big enough? | 20 oz. Room for seconds | 6 in / 15 cm · 20 oz with real cereal | Side view with dimension lines + kid hands |
| 5 | DETAIL | Quality? | Light, sturdy, stackable | Matte finish · Stacks neatly | Stack + macro |
| 6 | CARE | How do I clean it? | Dishwasher easy | Dishwasher ✓ · Microwave ✗ · Oven ✗ | Icon row |
| 7 | USES | What else? | Cereal to snacks | Cereal · Fruit · Yogurt · Picnic | 2x2 grid |
| 8 | WHO | Who's it for? | For kids. Loved by grown-ups | Toddlers · Kids · Adults | Family table |
| 9 | CLOSE | Who is ilohaus? | Joy lives here. | Logo | Kids table + Linen band |

**Note:** 'Shatter-resistant' copy is fighting the reviews. Use 'lightweight and sturdy' until the drop issue is solved. Microwave ✗ must be visible to avoid returns.

## Changelog
- 2026-10-19: Draft plan from listing + reviews. Standing design per slot; the weekly Creative Queue decides which slots get built.
