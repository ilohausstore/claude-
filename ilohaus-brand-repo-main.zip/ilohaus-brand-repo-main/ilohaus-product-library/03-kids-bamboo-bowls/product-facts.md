# Product facts: Bamboo Kids Bowls Set of 4 (20 oz, 6 in)

Source: live US listing B0D172KNNR + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: core
- brand_store_page: Home
- product_name (listing): ilohaus Bamboo Kids Bowls Set of 4, 20 oz Deep Cereal & Snack Bowls, 6-Inch
- short_name (internal): kids-bamboo-bowls
- parent_asin: B0D5HHMGQF
- child_asins (US, 90-day sales):
  - B0D172KNNR · SKU EBOW-CONFETTI · 90d US $4,159
  - B0DCFKN1W3 · SKU EBOW-FLEUR · 90d US $783
  - B0FH497PYG · SKU EBOW-PARTYPOP1 · 90d US $288
  - B0F389T3P5 · SKU EBOW-COLORPOP · 90d US $264
  - B0F389ZVTL · SKU EBOW-SAGE · 90d US $264
  - B0FH1SS2JX · SKU EBOW-SUNSET1 · 90d US $240
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Four 6-inch, 20 oz bowls made of bamboo fiber with food-grade melamine, printed patterns, for kids and adults.
- set_contents: 4 bowls
- variations: Confetti, Colorpop, Sage, Party Pop, Sunset (confirm list)

## Specs
- dimensions: 6 in (15 cm) diameter; 20 oz (600 ml); height TBC
- weight: TBC
- material: Bamboo fiber + food-grade melamine mix (A+ spec). **Not 100% bamboo**
- finish: Matte, slightly textured (reviews)
- base: —
- care: Dishwasher safe. **Not microwave or oven safe**

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| BPA-free, phthalate-free, food grade | Listing + A+ spec — keep supplier certificate on file |
| Dishwasher safe | Listing; reviews confirm |
| Lightweight, stackable | Listing; reviews |
| 6 in / 20 oz | A+ spec |

## Do NOT claim
- Unbreakable / shatterproof (reviews: broke when dropped)
- 100% bamboo or plastic-free (contains melamine)
- Microwave safe
- Eco-friendly/compostable without certification

## Buyer
- who buys it: Parents of toddlers and young kids (5–7 yrs mentioned); adults wanting light snack/cereal bowls
- top review praise: Perfect cereal size; cute patterns; durable; easy dishwasher clean
- top review complaints (images must pre-empt): Broke on first drop / arrived broken (fragile vs 'kids' promise); smaller than expected; colours less vibrant than photos

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
