# Bamboo Kids Bowls Set of 4 (20 oz, 6 in)

- **Line:** core
- **Parent ASIN:** B0D5HHMGQF (top child B0D172KNNR)
- **Status:** draft. Facts pulled from live US listing 2026-10-19; photos and TBC fields outstanding
- **US price / rating:** $23.96 · 4.3★ (119)
- **90-day US sales:** $5,997

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
