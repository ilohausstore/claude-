# 180-Day Prayer & Bible Study Journal

- **Line:** faith
- **Parent ASIN:** B0GDZWQHXS (top child B0DR258BR4)
- **Status:** DISCONTINUED (Sharon, 2026-10-19). No new images or copy work. Previously draft. Facts pulled from live US listing 2026-10-19; photos and TBC fields outstanding
- **US price / rating:** $12.17–$16.96 · 4.6★ (34)
- **90-day US sales:** $496

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
