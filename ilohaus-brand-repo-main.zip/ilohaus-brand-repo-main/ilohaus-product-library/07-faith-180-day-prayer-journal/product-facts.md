# Product facts: 180-Day Prayer & Bible Study Journal

Source: live US listing B0DR258BR4 + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: faith
- brand_store_page: Faith
- product_name (listing): ilohaus Bible Journal for Women, 180-Day Prayer & Bible Study Journal
- short_name (internal): faith-180-day-prayer-journal
- parent_asin: B0GDZWQHXS
- child_asins (US, 90-day sales):
  - B0DR258BR4 · SKU PLN-PINK-STILL · 90d US $159
  - B0D3GSZNBK · SKU PLN-BEIGE-STILL · 90d US $119
  - B0DR1WT7QH · SKU PLN-BEIGE-REJOICE · 90d US $115
  - B0FWRHJP5L · SKU PLN-BLUE-STILL · 90d US $68
  - B0DR2NS6JW · SKU PLN-BLUE-REJOICE · 90d US $35
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Undated 180-day guided prayer journal using the SOAP method: daily verse, prayer, thanks, reflection, blessings; monthly and weekly planners; linen cover; ribbon bookmark.
- set_contents: 1 journal
- variations: PINK-STILL, BEIGE-STILL, BEIGE-REJOICE (+ others; confirm)

## Specs
- dimensions: TBC
- weight: TBC
- material: Linen cover; cream 100gsm pages (A+ chart, TBC)
- finish: Linen with gold foil
- base: —
- care: —

## Faith only
- verse(s) on product, exact text: TBC (copy from print artwork)
- reference(s): TBC
- translation: TBC — must be KJV or WEB
- verse checked against source by / date: TBC

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| 180 undated days | Listing |
| SOAP method daily layout | Vine reviews |
| Monthly + weekly planner pages | A+ |
| Ribbon bookmark | A+; reviews |
| Ink/highlighter doesn't bleed | Vine review — confirm |

## Do NOT claim
- Error-free text until proofread (see complaints)
- Full verse quoted (only references are printed)
- Translation

## Buyer
- who buys it: Christian women starting a prayer habit; small groups; gift buyers
- top review praise: Attractive, sturdy; ribbon; SOAP structure helps; neutral colours; quality higher end
- top review complaints (images must pre-empt): **Spelling mistakes on pages ('gopsel')**; daily verse shows reference only, not the text; monthly calendar grid split across pages; limited writing space

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
