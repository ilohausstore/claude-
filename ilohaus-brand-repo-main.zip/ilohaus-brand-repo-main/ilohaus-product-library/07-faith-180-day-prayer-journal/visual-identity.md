# Visual identity: 180-Day Prayer & Bible Study Journal

## How the product must look
- shape / silhouette: Portrait hardback book, linen texture, gold foil title
- colours: Pink or beige linen, gold foil
- details that must be visible: Linen texture; gold foil; ribbon; daily page layout (SOAP)
- details AI usually gets wrong: Never AI-render inside pages. Use real page scans

## Accent colour
- faith → Olive. Tagline: "Hope lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: oak/walnut table, linen napkin (Linen/Sand), ceramic mug, small plant, Bible, tea cup, pen
- props never: blue items, glossy marble, clutter, crosses as decoration

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- **Stop before images:** a 1-star review reports spelling mistakes throughout the interior. Proofread the print file and fix the next print run first. Images will drive more buyers into that review.

## Changelog
- 2026-10-19: Created.
