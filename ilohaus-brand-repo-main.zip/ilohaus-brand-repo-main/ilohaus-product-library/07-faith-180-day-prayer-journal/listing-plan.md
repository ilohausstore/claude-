# Listing plan: 180-Day Prayer & Bible Study Journal

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: faith (Olive, "Hope lives here.")
- Sequence: C (adjusted from reviews)
- Top objections (reviews): **Spelling mistakes on pages ('gopsel')**; daily verse shows reference only, not the text; monthly calendar grid split across pages; limited writing space
- Top reasons people buy: Attractive, sturdy; ribbon; SOAP structure helps; neutral colours; quality higher end

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: cover front + ribbon |
| 2 | HOOK | How does it work? | 5 minutes with God | Verse · Prayer · Thanks · Reflect · Blessings | Real daily page with labels |
| 3 | HOW | How do I use it? | Read. Reflect. Pray. | 3 steps | 3 panels |
| 4 | LIFE | How will it feel? | Hope lives here. | — | Morning devotion, tea |
| 5 | DETAIL | What's inside? | Plan your faith | Monthly · Weekly · 180 days undated | Spread of planner pages |
| 6 | DETAIL | Quality? | Made to keep | Linen cover · Gold foil · Ribbon | Macro |
| 7 | WHO | Who's it for? | Start a prayer habit | New believers · Mums · Small groups | Lifestyle |
| 8 | GIFT | Giftable? | A gift of quiet time | Gift-ready | Wrapped |
| 9 | CLOSE | ilohaus Faith | Hope lives here. | Logo + FAITH lockup | Lifestyle + Linen band |

**Note:** **Stop before images:** a 1-star review reports spelling mistakes throughout the interior. Proofread the print file and fix the next print run first. Images will drive more buyers into that review.

## Changelog
- 2026-10-19: Draft plan from listing + reviews. Standing design per slot; the weekly Creative Queue decides which slots get built.
