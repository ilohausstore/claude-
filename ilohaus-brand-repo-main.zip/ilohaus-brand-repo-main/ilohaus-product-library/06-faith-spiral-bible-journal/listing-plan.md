# Listing plan: Bible Journal for Women, Hardcover Spiral, Lined

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: faith (Olive, "Hope lives here.")
- Sequence: C (adjusted from reviews)
- Top objections (reviews): Arrived creased/bent (packaging); 10% 1-star — read them
- Top reasons people buy: Beautiful cover; sturdy; paper quality, ideal line spacing; lays flat; good church size; discreet

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: journal front, slight angle showing spiral |
| 2 | HOOK | What's inside? | Room for every prayer | 150 lined pages · 100gsm cream · Lays flat | Open spread, pen |
| 3 | LIFE | How will it feel? | Hope lives here. | — | Quiet devotion by window, Bible beside |
| 4 | USES | How do I use it? | Notes, prayers, sermons | Sermon notes · Prayers · Verses · Gratitude | Church pew / table grid |
| 5 | DETAIL | Quality? | Made to keep | Hardcover · Gold spiral · No bleed | Macro spiral + page |
| 6 | SIZE | What size? | Fits your Bible bag | 5.5 x 8.3 in / A5 | Next to a Bible, in hands |
| 7 | SET | Which cover? | Pick your verse | All cover designs with references | Grid |
| 8 | GIFT | Giftable? | A gift that encourages | Daughter · Friend · Small group | Wrapped, with card |
| 9 | CLOSE | ilohaus Faith | Hope lives here. | Logo + FAITH lockup | Lifestyle + Linen band |

**Note:** Fix packaging (creasing) before spending on images — it's a review problem, not an image problem.

## Changelog
- 2026-10-19: Draft plan from listing + reviews. Standing design per slot; the weekly Creative Queue decides which slots get built.
