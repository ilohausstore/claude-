# Interior verses: KJV (Christian notebook, 40 lined pages)

Source files: NEW_LINES.zip (1.svg–40.svg), received 2026-10-19. Old headers were mostly NIV/ESV (need publisher permission on merchandise). Replaced with KJV, public domain. Text checked against the KJV text in the `pythonbible-kjv` package.

## Print rules
- Print the text exactly as below. Words in italics in printed KJV editions are kept, without brackets.
- "LORD" in capitals is how KJV renders God's name in the Old Testament. Set it in small caps if the font has them, otherwise "LORD". New Testament "Lord" stays as is (p. 37). Psalm 147:5 (p. 40) reads "our Lord" in KJV, so it stays "Lord".
- Pronouns for God stay lowercase (he, his, him), as in KJV. Don't mix in "He/His".
- Only two spelling changes from 1769 KJV: "to day" to "today", "for ever" to "forever" (p. 22, 33), so buyers don't read them as typos.
- Reference above the verse, translation "KJV" in small text on the copyright page (or after each verse if the layout allows).
- Proofread each header against this file twice before sending to print.

| Page | Reference | Print this (KJV) | Note |
|---|---|---|---|
| 1 | Psalm 46:10 | Be still, and know that I am God. | Excerpt (first clause) |
| 2 | Philippians 4:13 | I can do all things through Christ which strengtheneth me. | Full verse |
| 3 | 1 Thessalonians 5:16 | Rejoice evermore. | Full verse |
| 4 | Psalm 37:4 | Delight thyself also in the LORD; and he shall give thee the desires of thine heart. | Full verse |
| 5 | John 3:16 | For God so loved the world, that he gave his only begotten Son. | Excerpt |
| 6 | Romans 8:31 | If God be for us, who can be against us? | Excerpt (second sentence) |
| 7 | Psalm 119:105 | Thy word is a lamp unto my feet, and a light unto my path. | Full verse |
| 8 | Proverbs 3:5 | Trust in the LORD with all thine heart. | Excerpt |
| 9 | Matthew 5:14 | Ye are the light of the world. | Excerpt |
| 10 | 1 John 4:19 | We love him, because he first loved us. | Full verse |
| 11 | Psalm 56:3 | What time I am afraid, I will trust in thee. | Full verse |
| 12 | Matthew 19:26 | With God all things are possible. | Excerpt |
| 13 | James 1:19 | Let every man be swift to hear, slow to speak, slow to wrath. | Excerpt |
| 14 | Psalm 23:1 | The LORD is my shepherd; I shall not want. | Full verse |
| 15 | Romans 12:12 | Rejoicing in hope; patient in tribulation; continuing instant in prayer. | Full verse |
| 16 | Colossians 3:2 | Set your affection on things above, not on things on the earth. | Full verse |
| 17 | Ephesians 4:32 | And be ye kind one to another, tenderhearted, forgiving one another. | Excerpt |
| 18 | Psalm 118:24 | This is the day which the LORD hath made; we will rejoice and be glad in it. | Full verse |
| 19 | 1 Corinthians 16:14 | Let all your things be done with charity. | Full verse |
| 20 | Psalm 34:8 | O taste and see that the LORD is good. | Excerpt |
| 21 | Isaiah 41:10 | Fear thou not; for I am with thee. | Excerpt |
| 22 | Hebrews 13:8 | Jesus Christ the same yesterday, and today, and forever. | Full verse; spelling modernised (KJV: 'to day', 'for ever') |
| 23 | Micah 6:8 | To do justly, and to love mercy, and to walk humbly with thy God. | Excerpt (old text was a paraphrase) |
| 24 | John 14:27 | Peace I leave with you, my peace I give unto you. | Excerpt |
| 25 | Galatians 6:9 | Let us not be weary in well doing. | Excerpt |
| 26 | Psalm 27:1 | The LORD is my light and my salvation; whom shall I fear? | Excerpt |
| 27 | Matthew 6:33 | Seek ye first the kingdom of God, and his righteousness. | Excerpt |
| 28 | Psalm 69:30 | I will praise the name of God with a song, and will magnify him with thanksgiving. | Full verse |
| 29 | Romans 8:28 | All things work together for good to them that love God. | Excerpt (old text was a paraphrase) |
| 30 | 2 Corinthians 5:7 | For we walk by faith, not by sight. | Full verse (KJV parentheses dropped) |
| 31 | Psalm 31:24 | Be of good courage, and he shall strengthen your heart, all ye that hope in the LORD. | Full verse |
| 32 | Matthew 17:20 | Nothing shall be impossible unto you. | Excerpt (old text was not a verse) |
| 33 | Psalm 107:1 | O give thanks unto the LORD, for he is good: for his mercy endureth forever. | Full verse; spelling modernised (KJV: 'for ever') |
| 34 | John 1:9 | That was the true Light, which lighteth every man that cometh into the world. | Full verse |
| 35 | 1 Peter 5:7 | Casting all your care upon him; for he careth for you. | Full verse |
| 36 | John 14:1 | Let not your heart be troubled: ye believe in God, believe also in me. | Full verse |
| 37 | Romans 10:13 | For whosoever shall call upon the name of the Lord shall be saved. | Full verse ('Lord', not 'LORD', in the New Testament) |
| 38 | John 8:32 | And ye shall know the truth, and the truth shall make you free. | Full verse |
| 39 | John 14:15 | If ye love me, keep my commandments. | Full verse |
| 40 | Psalm 147:5 | Great is our Lord, and of great power: his understanding is infinite. | Full verse |

## Read-aloud check (KJV wording that may confuse buyers)
- p. 11 "What time I am afraid" = "whenever I am afraid"
- p. 15 "continuing instant in prayer" = "persistent in prayer"
- p. 19 "done with charity": "charity" means love here
- p. 16 "Set your affection on things above"
If any of these feel wrong for the brand, swap the reference for a different KJV verse rather than editing the wording.

## Changelog
- 2026-10-19: All 40 switched from NIV/ESV/paraphrase to KJV.
