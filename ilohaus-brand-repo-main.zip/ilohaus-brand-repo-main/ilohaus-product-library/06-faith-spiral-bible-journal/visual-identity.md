# Visual identity: Bible Journal for Women, Hardcover Spiral, Lined

## How the product must look
- shape / silhouette: A5 portrait journal, gold spiral on left
- colours: Per cover design; soft pastels (pink bow on some)
- details that must be visible: Exact cover art + verse; gold spiral; lined cream page inside; size in hands
- details AI usually gets wrong: Never AI-render the cover verse; composite the real cover. Don't show it as a guided journal

## Accent colour
- faith → Olive. Tagline: "Hope lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: oak/walnut table, linen napkin (Linen/Sand), ceramic mug, small plant, Bible, tea cup, pen
- props never: blue items, glossy marble, clutter, crosses as decoration

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- Fix packaging (creasing) before spending on images — it's a review problem, not an image problem.

## Changelog
- 2026-10-19: Created.
