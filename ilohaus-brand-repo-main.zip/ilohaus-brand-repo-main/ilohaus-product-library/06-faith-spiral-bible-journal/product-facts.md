# Product facts: Bible Journal for Women, Hardcover Spiral, Lined

Source: live US listing B0FC26DJR7 + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: faith
- brand_store_page: Faith
- product_name (listing): ilohaus Bible Journal for Women, Prayer Journal with Lined Pages, Hardcover
- short_name (internal): faith-spiral-bible-journal
- parent_asin: B0FC2DC362
- child_asins (US, 90-day sales):
  - B0FC26DJR7 · SKU NOTB-ECCLES311 · 90d US $1,159
  - B0GWLYNZRW · SKU NOTB-GODSAYS · 90d US $558
  - B0GCBFG1JL · SKU NOTB-PHILIP413 · 90d US $321
  - B0GWM377PX · SKU NOTB-PSALM233 · 90d US $293
  - B0GC95Z9PW · SKU NOTB-ROMANS838 · 90d US $195
  - B0FC26KGG7 · SKU NOTB-JESUSW · 90d US $95
  - B0HK7CWZWN · SKU NOTB-JEREMIAH2911 · 90d US $0
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Hardcover spiral journal, 5.5 x 8.3 in, 150 cream 100gsm lined pages, gold double spiral, verse cover designs.
- set_contents: 1 journal (or 3-pack)
- variations: Covers: Ecclesiastes 3:11, Psalm 23:3, God Says, Philippians 4:13, Romans 8:38-39, There Was Jesus, Psalm 46:10 (new SKU)

## Specs
- dimensions: 5.5 x 8.3 in (A5)
- weight: TBC
- material: Hardcover board; cream 100gsm paper
- finish: Cover finish TBC
- base: —
- care: —

## Faith only
- verse(s) on product, exact text: interior pages, see `interior-verses-kjv.md` (40 verses). Cover verses TBC
- reference(s): see `interior-verses-kjv.md`
- translation: KJV (interior switched from NIV/ESV on 2026-10-19). Cover verses: TBC, must also be KJV
- verse checked against source by / date: interior checked against KJV text 2026-10-19; cover TBC

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| 150 lined pages, cream 100gsm | A+ comparison chart |
| Lays flat (spiral) | Vine reviews |
| No bleed | A+ — confirm with pen test |
| Gold double spiral | A+ |

## Do NOT claim
- Guided prompts (this is lined only — that's the 180-day journal)
- Leather
- Translation of cover verses until confirmed KJV/WEB

## Buyer
- who buys it: Christian women; church notes; Bible study; gifts for daughters, friends
- top review praise: Beautiful cover; sturdy; paper quality, ideal line spacing; lays flat; good church size; discreet
- top review complaints (images must pre-empt): Arrived creased/bent (packaging); 10% 1-star — read them

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
- 2026-10-19: Interior verses switched to KJV. This is the Faith product Sharon is pushing.
