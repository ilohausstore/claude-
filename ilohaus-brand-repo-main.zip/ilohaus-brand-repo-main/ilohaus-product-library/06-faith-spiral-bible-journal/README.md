# Bible Journal for Women, Hardcover Spiral, Lined

- **Line:** faith
- **Parent ASIN:** B0FC2DC362 (top child B0FC26DJR7)
- **Status:** draft. Facts pulled from live US listing 2026-10-19; photos and TBC fields outstanding
- **US price / rating:** $13.96 (3-pack $32.96) · 4.2★ (30), Amazon's Choice
- **90-day US sales:** $2,621

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
