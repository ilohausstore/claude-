# Visual identity: Ceramic Marble Coasters Set of 6 with Holder

## How the product must look
- shape / silhouette: Round, 4 in, thin disc, cork base
- colours: Per design; colourful. Keep scenes neutral (Linen/Sand/oak) so the design is the colour
- details that must be visible: Each design's exact print; gold holder; gift box; cork base
- details AI usually gets wrong: Don't render real marble veining with gloss; it's a matte print. Don't show coffee spilled on a light design (stain objection)

## Accent colour
- core → Honey. Tagline: "Joy lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: oak/walnut table, linen napkin (Linen/Sand), ceramic mug, small plant
- props never: blue items, glossy marble, clutter, any scripture

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- Image 6 (CARE) pre-empts the #1 complaint (coffee stains). Better to set expectations than collect 1-star reviews.

## Changelog
- 2026-10-19: Created.
