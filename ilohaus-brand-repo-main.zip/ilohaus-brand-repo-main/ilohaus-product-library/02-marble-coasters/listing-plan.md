# Listing plan: Ceramic Marble Coasters Set of 6 with Holder

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: core (Honey, "Joy lives here.")
- Sequence: A (adjusted from reviews)
- Top objections (reviews): Coffee/coloured drinks stain permanently; some chip easily; print looks uneven on some designs (DE review)
- Top reasons people buy: Look exactly like the picture; vibrant; absorbent; soft cork bottom; love the inspirational note

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: 6 coasters fanned + gold holder |
| 2 | HOOK | Will it work? | Dry table, every time | Absorbs fast · Won't stick to cups · Cork base | Infographic |
| 3 | LIFE | How will it look? | A little colour, a lot of joy | — | Iced drink on coffee table, plants, soft light |
| 4 | SET | What do I get? | 6 coasters + gold holder | Design name | Flat lay + holder |
| 5 | DETAIL | Is it well made? | Printed to last | Matte print · Cork base · Gold holder | Macro |
| 6 | CARE | How do I look after it? | Easy care | Rinse after coffee · Hand wash · Air dry | Icon row over detail shot |
| 7 | SIZE | Will my glass fit? | Fits most cups | 4 in / 10 cm | Under mug + wine glass |
| 8 | GIFT | Is it giftable? | Gift box included | Box · Holder · Note card | Box open on linen |
| 9 | CLOSE | Who is ilohaus? | Joy lives here. | Logo | Lifestyle + Linen band |

**Note:** Image 6 (CARE) pre-empts the #1 complaint (coffee stains). Better to set expectations than collect 1-star reviews.

## Changelog
- 2026-10-19: Draft plan from listing + reviews. Standing design per slot; the weekly Creative Queue decides which slots get built.
