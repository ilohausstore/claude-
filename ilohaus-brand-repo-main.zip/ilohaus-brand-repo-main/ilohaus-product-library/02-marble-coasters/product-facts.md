# Product facts: Ceramic Marble Coasters Set of 6 with Holder

Source: live US listing B0DJVXXN19 + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: core
- brand_store_page: Home
- product_name (listing): Ceramic Marble Coasters Set of 6, Absorbent Drink Coasters for Table
- short_name (internal): marble-coasters
- parent_asin: B0FWPM9VC7
- child_asins (US, 90-day sales):
  - B0DJVXXN19 · SKU COS-LEAF · 90d US $6,103
  - B0D7Z7FL69 · SKU COS-FLEUR · 90d US $1,536
  - B0DSFSNG66 · SKU COS-ZENMANDALA · 90d US $455
  - B09C1MZ9X3 · SKU PN-5MW2-J7KE · 90d US $360
  - B0GH6KMHXF · SKU COS-IMPRESSIONS · 90d US $360
  - B0C8M5C1Y6 · SKU AD-T02-100 · 90d US $284
  - B09P389N2R · SKU CC-001-0002 · 90d US $271
  - B0FMX93G37 · SKU COS-TWINKLEBL · 90d US $265
  - B0DXV9H1GZ · SKU COS-SAPPHIRE · 90d US $262
  - B0CQQGGS1C · SKU COS-PORCELAIN · 90d US $152
  - B0D2XP5FDR · SKU COS-WAVES · 90d US $114
  - B0F53NVB4H · SKU COS-BLOSSOM · 90d US $114
  - B0D2XPHCCC · SKU COS-BOHO · 90d US $38
  - B0GH6KKYZH · SKU COS-BLOOM · 90d US $0
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Six round absorbent ceramic coasters (diatomite) with printed marble/pattern designs, cork base and gold holder, in a gift box.
- set_contents: 6 round coasters + 1 gold holder + gift box (per A+); inspirational note card (per reviews)
- variations: Leaf, Fleur, Zenmandala, Teal, Black, Blossom (listing says 10+ designs; confirm list)

## Specs
- dimensions: 4 in (≈10 cm) diameter; thickness TBC
- weight: TBC
- material: Ceramic with diatomite; high-quality print, fade-resistant (listing)
- finish: Matte printed top
- base: Cork, non-slip
- care: Hand wash only. Rinse under running water after coffee spills to prevent staining

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| Absorbs condensation fast | Listing; reviews |
| Doesn't stick to cup bottoms | A+ 'No more sticky coasters' |
| Cork base, non-slip | Listing; reviews |
| Gift box + gold holder | A+ 'Gift Box Included' |
| Fade-resistant print | A+ claim — TBC with supplier test |

## Do NOT claim
- Stain resistant (reviews: coffee stains permanently)
- Chip-proof
- Dishwasher safe
- Outdoor uncovered use (listing says covered outdoor only)

## Buyer
- who buys it: Home decor and colour lovers; gift buyers (college, housewarming, Christmas)
- top review praise: Look exactly like the picture; vibrant; absorbent; soft cork bottom; love the inspirational note
- top review complaints (images must pre-empt): Coffee/coloured drinks stain permanently; some chip easily; print looks uneven on some designs (DE review)

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
