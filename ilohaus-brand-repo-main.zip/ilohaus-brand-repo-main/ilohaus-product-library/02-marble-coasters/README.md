# Ceramic Marble Coasters Set of 6 with Holder

- **Line:** core
- **Parent ASIN:** B0FWPM9VC7 (top child B0DJVXXN19)
- **Status:** draft. Facts pulled from live US listing 2026-10-19; photos and TBC fields outstanding
- **US price / rating:** $18.96 · 4.5★ (590)
- **90-day US sales:** $10,315

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
