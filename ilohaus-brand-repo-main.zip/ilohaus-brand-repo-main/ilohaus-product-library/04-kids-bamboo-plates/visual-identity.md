# Visual identity: Bamboo Kids Plates Set of 4 (8 in)

## How the product must look
- shape / silhouette: Round flat plate, 8 in, slight rim
- colours: Per colourway
- details that must be visible: Exact print; matte texture; the matching bowl in at least one image
- details AI usually gets wrong: Don't render glossy ceramic. Don't show microwave

## Accent colour
- core → Honey. Tagline: "Joy lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: oak/walnut table, linen napkin (Linen/Sand), ceramic mug, small plant
- props never: blue items, glossy marble, clutter, any scripture

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- Image 7 cross-sells the bowls; FBT already pairs them.

## Changelog
- 2026-10-19: Created.
