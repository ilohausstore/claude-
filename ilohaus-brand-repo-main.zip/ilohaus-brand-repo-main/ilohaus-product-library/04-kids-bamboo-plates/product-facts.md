# Product facts: Bamboo Kids Plates Set of 4 (8 in)

Source: live US listing B0DCFQ8669 + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: core
- brand_store_page: Home
- product_name (listing): ilohaus Bamboo Kids Plates Set of 4, 8-Inch Non-Toxic Toddler Dinnerware
- short_name (internal): kids-bamboo-plates
- parent_asin: B0DCDVB64W
- child_asins (US, 90-day sales):
  - B0DCFQ8669 · SKU EPLA-CONFETTI · 90d US $2,758
  - B0DCFWGNW3 · SKU EPLA-FLEUR · 90d US $853
  - B0F3CLFY7Q · SKU EPLA-COLORPOP · 90d US $587
  - B0FC1L8KNN · SKU EPLA-SUNSET · 90d US $503
  - B0FC1SV4T9 · SKU EPLA-PARTYPOP · 90d US $356
  - B0DCFXNB5M · SKU EPLA-PETALS · 90d US $204
  - B0F3C82Q6D · SKU EPLA-SAGE · 90d US $126
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Four 8-inch plates of bamboo fiber reinforced with food-grade melamine, matte printed patterns. Matches the bamboo bowls.
- set_contents: 4 plates
- variations: Confetti, Sage, Sunset, Petals (+ others; confirm)

## Specs
- dimensions: 8 in (≈20 cm) diameter; depth TBC
- weight: TBC
- material: Bamboo fiber + food-grade melamine (A+ spec)
- finish: Matte, slightly textured
- base: —
- care: Dishwasher safe (top rack per review). **Not microwave safe**

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| BPA-free, food grade | Listing — keep certificate on file |
| Dishwasher safe | Listing; reviews |
| Lightweight, stackable | A+ |
| Matches the bamboo bowls | A+ — show together |

## Do NOT claim
- Unbreakable
- 100% bamboo / plastic-free
- Microwave safe (one review microwaves them; do NOT echo)

## Buyer
- who buys it: Parents of toddlers; adults for light meals, campers
- top review praise: Cute; sturdy, quality weight; easy to clean; love the Bible verse card and the brand mission
- top review complaints (images must pre-empt): Some find them small; one questions 'bamboo' vs recycled material

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
