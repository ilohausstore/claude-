# Listing plan: Bamboo Kids Plates Set of 4 (8 in)

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: core (Honey, "Joy lives here.")
- Sequence: B (adjusted from reviews)
- Top objections (reviews): Some find them small; one questions 'bamboo' vs recycled material
- Top reasons people buy: Cute; sturdy, quality weight; easy to clean; love the Bible verse card and the brand mission

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: 4 plates fanned |
| 2 | HOOK | Is it safe? | Safe for little hands | BPA-free · Food grade · Lightweight | Infographic |
| 3 | LIFE | How will it feel? | Mealtime, made joyful | — | Toddler lunch at family table |
| 4 | SIZE | Right size? | 8 in. Just right | 8 in / 20 cm, real food portion | Top view with portion |
| 5 | DETAIL | Quality? | Sturdy and light | Matte finish · Stacks flat | Stack + macro |
| 6 | CARE | Cleaning? | Dishwasher easy | Dishwasher ✓ · Microwave ✗ | Icon row |
| 7 | SET | Complete the set | Pairs with our bowls | Plate + bowl | Plate + bowl together |
| 8 | WHO | Who for? | Kids to grown-ups | Toddlers · Picnics · Camping | Family / picnic |
| 9 | CLOSE | Who is ilohaus? | Joy lives here. | Logo | Lifestyle + Linen band |

**Note:** Image 7 cross-sells the bowls; FBT already pairs them.

## Changelog
- 2026-10-19: Draft plan from listing + reviews. Standing design per slot; the weekly Creative Queue decides which slots get built.
