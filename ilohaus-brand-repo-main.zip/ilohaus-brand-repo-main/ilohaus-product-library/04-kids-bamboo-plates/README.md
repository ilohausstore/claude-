# Bamboo Kids Plates Set of 4 (8 in)

- **Line:** core
- **Parent ASIN:** B0DCDVB64W (top child B0DCFQ8669)
- **Status:** draft. Facts pulled from live US listing 2026-10-19; photos and TBC fields outstanding
- **US price / rating:** $20.96 · 4.6★ (75)
- **90-day US sales:** $5,386

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
