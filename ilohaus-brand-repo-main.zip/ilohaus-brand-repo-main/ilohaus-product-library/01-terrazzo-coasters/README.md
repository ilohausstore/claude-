# Terrazzo Coasters Set of 6 with Holder

- **Line:** core
- **Parent ASIN:** B0BHMRWQSC (top child B0BZNZKK6V)
- **Status:** draft. References in for TZM-001-001 and TZ-001-001; 16 variants, cork base, scale and packaging photos outstanding
- **US price / rating:** $18.96 · 4.6★ (489)
- **90-day US sales:** $51,347 (64% of US sales)

Files: `product-facts.md`, `visual-identity.md`, `asset-evidence.md`, `listing-plan.md`, `references/`.
