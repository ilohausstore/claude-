# Product facts: Terrazzo Coasters Set of 6 with Holder

Source: live US listing B0BZNZKK6V + A+ content + reviews, pulled 2026-10-19. Anything marked TBC must be confirmed before it appears in an image.

## Identity
- line: core
- brand_store_page: Home
- product_name (listing): Terrazzo Coasters Set of 6, Colorful Boho Absorbent Ceramic Coasters
- short_name (internal): terrazzo-coasters
- parent_asin: B0BHMRWQSC
- child_asins (US, 90-day sales):
  - B0BZNZKK6V · SKU TZM-001-001 · 90d US $22,604
  - B0BZNYDNTS · SKU TZ-001-001 · 90d US $8,035
  - B0DJVX7NB8 · SKU COS-GRANITE · 90d US $3,797
  - B0D2XN8WQ4 · SKU COS-MOSAIC · 90d US $2,605
  - B0FBWFZ1WM · SKU COS-TMARBLEB · 90d US $2,588
  - B0FJQL9GJ4 · SKU COS-GRANITEBL · 90d US $2,292
  - B0F53NYSW7 · SKU COS-SUNSET · 90d US $2,156
  - B0FJQKZ8L4 · SKU COS-MOSAICBL · 90d US $1,649
  - B0FJQNW7WZ · SKU COS-CONFETTIT1BL · 90d US $1,199
  - B0DGG7RTHT · SKU COS-MDPEBBLE · 90d US $1,046
  - B0FJQDTRHB · SKU COS-SUNSETBL · 90d US $1,043
  - B0CVRSPDC6 · SKU COS-PASTELTERRAZZO · 90d US $785
  - B0CVRMJXW1 · SKU COS-SAGETERRAZZO · 90d US $520
  - B0DXV9DW54 · SKU COS-COLORPOP · 90d US $384
  - B0GH6FCJV9 · SKU COS-TERRA · 90d US $228
  - B0GH66Y75S · SKU COS-SPLASH · 90d US $190
  - B0CMGRVBJC · SKU COS-PEBBLES · 90d US $133
  - B0DGG6Q4BR · SKU COS-COLORBURST · 90d US $95
- marketplaces: US / CA / AU (CA, AU child ASINs TBC)

## What it is
- one-line description: Six round absorbent ceramic-stone coasters with a printed terrazzo pattern, cork backing and a holder.
- set_contents: 6 round coasters + 1 holder
- variations: Marble, Confetti, Terra, Granite, Granite Black Holder, Mosaic (+ others; confirm full list)

## Specs
- dimensions: Coaster 4 in (≈10 cm) diameter; thickness TBC. Listing 'Item Dimensions 4.9 x 3 in' looks like the holder/box, TBC
- weight: 1.46 lb set (listing)
- material: Absorbent ceramic stone with diatomite; terrazzo look is a **digital print**, not real terrazzo
- finish: Matte printed top
- base: Cork, non-slip
- care: Hand wash only. Rinse under running water after coffee spills

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
| Absorbs condensation from hot and cold drinks | Listing bullets; reviews confirm |
| Non-slip cork base protects wood, glass, stone | Listing bullets; reviews ('cork secures the coaster') |
| Holder included | Listing; reviews say the holder 'sold me' |
| Fits mugs, tumblers, wine glasses (4 in) | Listing |

## Do NOT claim
- "Handcrafted" (printed on the box, unconfirmed; coasters are digitally printed)
- Real terrazzo or real stone chips (it's a print. Reviews call this out)
- Stain-proof or coffee-proof
- Dishwasher safe
- Heat-proof / trivet use (unconfirmed)
- Gift box included (TBC for this family; marble family says yes)

## Buyer
- who buys it: Home decor buyers, mid-century/boho styles; housewarming and wedding gift buyers
- top review praise: Absorbs well; sturdy; holder keeps them together; pattern hides coffee rings; looks great on MCM tables
- top review complaints (images must pre-empt): Pattern is printed, not real terrazzo (expectation gap); colours less vibrant than photos; print slightly bleeds on edges; 'overpriced' unless on sale; stone chips if dropped

## Packaging
- box / holder / insert: see set_contents; photograph the real packaging for `references/`

## Changelog
- 2026-10-19: Created from live listing, A+ and reviews.
