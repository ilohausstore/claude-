# Visual identity: Terrazzo Coasters Set of 6 with Holder

## How the product must look
- shape / silhouette: Round, 4 in, thin disc, cork base visibly darker brown underneath
- colours: Varies by colourway; speckled multi-colour chips on light base. Map to palette in scenes, not product
- details that must be visible: Speckle pattern exactly as reference (each coaster in a set has the same print); cork base; holder style and colour (gold or black)
- details AI usually gets wrong: AI makes it look like real polished terrazzo with depth, or glossy. It's a **matte print**. Don't oversaturate colours (top complaint is 'less vibrant than photo')

## Accent colour
- core → Honey. Tagline: "Joy lives here."

## Scene preferences
- best scenes: see `listing-plan.md` slot 3
- props allowed: wood coffee table with grain, woven rattan tray or placemat, crumpled linen, iced latte or mug, plate of cookies, open magazine or book, candle, dried flowers, people (sleeves, hands, knees) in soft focus
- props never: blue items, glossy marble, any scripture. Lived-in is good (see 03); messy-dirty is not
- "No blue" applies to props, backgrounds and graphics only. **Never recolour the product**: some prints (COS-PASTELTERRAZZO, TZM-001-001) have teal or slate-blue chips; reproduce them exactly

## Approved past images
- (add OneDrive link + what worked)

## Rules learned from feedback
- Slot 2 must also fix the expectation gap: say 'terrazzo-print' or 'terrazzo-look' honestly in copy. Show colours true to life; over-saturated photos are driving 3-star reviews.
- Image tool: Gemini (Nano Banana Pro) matches the terrazzo print; ChatGPT GPT Image renders it as a sticker on a white disc with oversaturated chips and a cream base. Use Gemini for this product.
- Judge print accuracy against the in-use photos (TZM ref-05, ref-07), not only the studio close-up (ref-03); at normal viewing distance the print reads sparser than in the close-up.
- Infographic slots (HOOK, DETAIL): smooth hard matte surface, never fabric. A tablecloth undercuts the "protects your table" claim and puts texture behind text.

- Slot 2 is product-first: the set in its holder, large, same angle as MAIN (see 08 §2a). Diagrams and test sequences go in later slots.
- Absorption proof must be real photos of our coaster, never AI and never a generic disc. Material is **diatomite**, never "dolomite". Don't claim "vibrant" colours.

## Changelog
- 2026-10-21: Props updated for the lived-in style; LIFE v1 (empty oak table) rejected as too clean.
- 2026-10-20: Rules from review of live image 2: product-first slot 2; real-photo absorption proof; diatomite wording; no "vibrant".
- 2026-10-20: Clarified: product's own blue/teal chips stay; no-blue rule is for props and backgrounds.
- 2026-10-20: Added image-tool rule (Gemini over ChatGPT for terrazzo print) after slot 2 tests.
- 2026-10-19: Created.
