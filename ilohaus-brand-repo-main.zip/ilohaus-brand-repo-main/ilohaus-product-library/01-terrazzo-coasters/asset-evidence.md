# Asset evidence: Terrazzo Coasters Set of 6 with Holder

The AI opens the files in the variant's `references/<SKU>_<ASIN>/` folder before generating. Repo copies are resized to 2000 px, JPG q85. Full-size originals stay in OneDrive.

**Variant mapping comes from Scale Insights (SKU → ASIN), not the Master Product List (being updated).**

## Variants with references

### TZM-001-001 · B0BZNZKK6V (best seller, $22.6k / 90 days US)
Print: small, dense chips, mostly orange and coral, with teal, deep green, grey, mustard, a few small blue and maroon chips, semi-transparent white/grey chips, fine black speckle on off-white. Edge plain white.

| File | What it shows | Use it for |
|---|---|---|
| ref-03-front-one-standing-on-stack-white-landscape.jpg | One coaster upright on the stack in gold holder, white, landscape | MAIN, exact print, holder shape |
| ref-05-lifestyle-tea-topdown.jpg | Tea mug on coaster, holder, spoon, pampas | Approved scene style |
| ref-06-lifestyle-dessert-topdown.jpg | Dessert jar on coaster, holder | Approved scene style |
| ref-07-lifestyle-pour-hand-iced-latte.jpg | Hand pouring espresso into iced latte on coaster | LIFE / hands-in-frame |
| ref-08-set-of-6-flatlay-white-composite.jpg | All 6 flat in a triangle on white. **Composite**: the real face from ref-03 cut out, lighting evened, copied 6× at different rotations (all 6 coasters share one design) | SET image, print reference |

Holder with a full stack of 6: no TZM photo. Holder is the same across variants, so use COS-MOSAIC ref-01 for holder shape/proportions only, never for print.

### COS-MOSAIC · B0D2XN8WQ4
Print: large flat shards (maroon, deep teal, navy, mustard, coral, sage) with fine black speckle on off-white. Print wraps onto the edge as coloured streaks (the "print bleeds on edges" complaint).

Folder: `references/COS-MOSAIC_B0D2XN8WQ4/`
| File | What it shows | Use it for |
|---|---|---|
| ref-01-stack-in-holder-white.jpg | 6 stacked in gold holder, white, portrait | MAIN, holder shape, edge |
| ref-02-front-one-standing-on-stack-white.jpg | One coaster upright on the stack, portrait | Exact print, MAIN |
| ref-03-set-of-6-flatlay-white.jpg | All 6 flat in a triangle | SET image: each coaster's print |

### COS-PASTELTERRAZZO · B0CVRSPDC6 ($785 / 90 days US)
Print: pastel. Large pale chips (mint/aqua, greige/beige), medium coral and deep teal chips, a few **slate-blue/periwinkle** and mustard chips, fine dark and coral speckle on off-white. Print wraps onto the edge as pale aqua/coral streaks (like COS-MOSAIC). All 6 coasters share one design.

Folder: `references/COS-PASTELTERRAZZO_B0CVRSPDC6/`
| File | What it shows | Use it for |
|---|---|---|
| ref-01-front-one-standing-on-stack-white.jpg | One coaster upright on the stack in gold holder, white, portrait | MAIN, exact print, holder, edge streaks |
| ref-02-set-of-6-stack-plus-two-loose-white.jpg | 4 stacked + 2 loose, no holder, white | SET (count), print at normal viewing distance |
| ref-03-print-face-crop.jpg | **Crop** of ref-01's original (6000 px): full coaster face, straight on | Exact print layout and colours |
| ref-04-print-macro-crop.jpg | **Crop** of ref-01's original: centre of the face, close-up | DETAIL (matte print texture, chip edges) |

Crops are cut from the real photo, not AI. No lifestyle photos for this variant: use the approved scene style from TZM ref-05/06/07, with this variant's print. No real flat lay of all 6: if a SET image needs one, build a composite the same way as TZM ref-08 (cut out ref-03, copy 6× at different rotations).

### TZ-001-001 · B0BZNYDNTS ($8.0k / 90 days US)
| File | What it shows | Use it for |
|---|---|---|
| ref-01-front-one-standing-on-stack-white.jpg | One coaster upright on stack in gold holder, white | MAIN, exact print |
| ref-02-lifestyle-fruit-drink-angle.jpg | Fruit drink on coaster, holder behind | LIFE |
| ref-03-lifestyle-fruit-drink-angle-wide.jpg | Same, wider with fern | LIFE |
| ref-04-lifestyle-fruit-drink-topdown.jpg | Top-down, holder + loose coaster + drink | LIFE / SET context |
| ref-05-lifestyle-fruit-drink-topdown-pampas.jpg | Top-down with pampas | LIFE |
| ref-06-macro-print-edge-iced-latte.jpg | Close-up of print and edge under glass | DETAIL (print is matte, edge white) |
| ref-07-macro-print-condensation.jpg | Close-up with water droplets | HOOK (absorbency) |

### _all-variants (shared by every terrazzo SKU)
| File | What it shows | Use it for |
|---|---|---|
| ref-cork-base.jpg | Coaster flipped: full cork base, white ceramic rim, print visible on the edge | HOOK / DETAIL (cork base claim), CARE |
| ref-packaging-box-3d-mockup.jpg | 3D mock-up of the kraft mailer box: logo, "Handcrafted Absorbent Coasters", "6 PACK", "WE THINK YOU'VE GOT GREAT TASTE!" (EN + FR) | GIFT slot, unboxing scenes |
| ref-packaging-box-artwork-flat.jpg | Flat box artwork (all panels) | Exact box text and layout |
| ref-absorb-1-0s.jpg | Absorption test, COS-TERRA, water just poured (wet patch visible) | Slot 5 proof, frame 1 "Drop" |
| ref-absorb-2-3s.jpg | Same, 3 sec later (patch shrinking) | Slot 5 frame 2 |
| ref-absorb-3-6s.jpg | Same, 6 sec (faint) | Slot 5 frame 3 (optional) |
| ref-absorb-4-dry.jpg | Same, dry at about 9 sec | Slot 5 last frame "Dry" |

Rules: every variant may use these three. Each variant still needs its **own** print photos. The box is a 3D mock-up, not a photo: before using it in a listing, confirm it matches the box you ship. Don't show or repeat the word "Handcrafted" until confirmed (see `04-source-audit.md`).

## What the photos show (rules for AI)
- Base colour is off-white; chips are flat printed shapes, not raised or glossy.
- Coaster edge is plain white on TZM-001-001. COS-MOSAIC print wraps onto the edge as colour streaks; show it as it is.
- Holder is gold wire with two loops and a flat base; coasters sit horizontally.
- Approved shoot style: blush/beige plinth, pampas grass, fern, gold-and-black spoon, soft daylight. Close to the brand palette; keep it.

## Still missing (all variants)
| Needed | Why |
|---|---|
| Real photo of the packed box (optional) | GIFT image is stronger with a real photo than a mock-up |
| ~~Absorption test~~ **Done 2026-10-21** (see `_all-variants/ref-absorb-*`). Method kept for reshoots: (needed for slot 5, shared by all SKUs; also usable as a listing/TikTok video) | Every terrazzo SKU is the same diatomite stone. Use COS-TERRA (lightest print on hand). **Method: one continuous video, phone on a stand, never handheld**, top-down, coaster centred and not moved. Pull the 4 stills (0 s, ~3 s, ~8 s, dry) from the video, so framing is identical. **Water: about 1 tablespoon poured slowly onto the centre** (or set down a glass wet with condensation). No water may run off the edge: a puddle on the table disproves the claim. **Surface: one solid wooden board, no slat gaps, no engraved logos** (warm wood also shows the coaster edge better than a white counter). **Light from one side, low** (window to the side, not overhead), so the water shines; phone tilted about 20–30° instead of straight down. A flat, overhead-lit puddle is invisible in stills. Coaster fills at least half the frame; nothing else in frame (no hand, stand or bottle). Record in 4K and send the **original file** (Google Drive / AirDrop), never via WhatsApp (it shrinks it to 576p). Note the real time to dry. Save stills in `_all-variants/` as `ref-absorb-1-0s.jpg` … `ref-absorb-4-dry.jpg`. Video original goes to OneDrive, not the repo |
| References for the other 15 variants | Each variant has a different print; AI must not reuse one print for another |

## SIZE image: no hand photo needed
Use TZM-001-001 ref-07 (hand + glass on coaster) and ref-03 (front) as references. AI makes the hand and mug; the coaster must match the reference. Add a **4 in / 10 cm** dimension line in Canva. QC: coaster slightly wider than a standard mug base, never mug-sized.

## In OneDrive (originals)
| Path | What it is |
|---|---|
| OneDrive\CLAUDE VIBE\ilohaus\products\01-terrazzo-coasters\raw\ | Full-size shoot files (Sharon_s Shoot_*, IMG_99*) |
| OneDrive\CLAUDE VIBE\ilohaus\packaging\coaster-box\ | Box source: Source File.ai, Print ready.pdf, diecutcoaster.pdf, 3D.jpg, Design 1.jpg |

## Changelog
- 2026-10-21: Test 3 (IMG_2858, COS-TERRA, wood board, ~1 tbsp) usable: wet patch clear at 0 and 3 s, gone at about 9 s. 4 stills saved to _all-variants. One test only: say "dry in seconds" on the image, not a precise claim like "dries in 9 seconds". Video original in Sharon's Google Drive (IMG_2858.MOV).
- 2026-10-21: Test 2 (IMG_2857, COS-TERRA, white counter, ~1 tsp, overhead light): no run-off and dry in about 6–8 s, but the wet patch is barely visible, so frames 2–4 look identical. Not usable as stills. Added side light, camera tilt and framing rules.
- 2026-10-21: Absorption shot method set after first test (COS-TERRA): video on a stand, 1 tbsp water, no run-off, solid surface, original file. First test not usable (handheld, run-off onto table, slatted bench with logo, WhatsApp 576p). Dry at about 8 to 10 s.
- 2026-10-20: Absorption series can be any variant; saved in _all-variants and shared by every SKU.
- 2026-10-20: Added absorption test photo series to Still missing (slot 5 is blocked without it).
- 2026-10-20: Added COS-PASTELTERRAZZO (2 photos + 2 crops from the original). Product print contains blue chips: reproduce as is (see 02 colour rules).
- 2026-10-20: Added TZM ref-08 flat-lay composite built from ref-03 (all 6 coasters same design, per Sharon).
- 2026-10-20: TZM ref-01, ref-02, ref-04 were COS-MOSAIC (confirmed by Sharon for 01/02; 04 is the same print). Moved to COS-MOSAIC_B0D2XN8WQ4 (04 renamed ref-03). Edge rule split by variant.
- 2026-10-20: Added _all-variants (cork base, box mock-up, box artwork); SIZE method without hand photo.
- 2026-10-19: Added references for TZM-001-001 (7) and TZ-001-001 (7) from Sharon's shoot.
- 2026-10-19: Created.
