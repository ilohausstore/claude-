# Prompt pack: TZM-001-001 · B0BZNZKK6V (Terrazzo Coasters, core line)

Built 2026-10-21 from Creative Queue 2026-10-20 (Build 1) + repo `listing-plan.md` (Sequence A, 9 slots). Where the queue brief and the repo disagree, the repo wins (it was updated after the brief: slot 3 re-briefed lived-in, slot 5 unblocked with real timings).

## Gemini setup (once)
- gemini.google.com, signed in as ilohaus.store@gmail.com, model **Nano Banana Pro**. New chat for this product only.
- Upload: `TZM-001-001_B0BZNZKK6V/ref-03-front-one-standing-on-stack-white-landscape.jpg` + `ref-07-lifestyle-pour-hand-iced-latte.jpg`. Add the extra refs named per slot.
- Ask for square 1:1, 2K. No text in any image. Text, badges and logo go on in Canva.

## Product lock (paste first, before any slot prompt)
```
These reference photos show my exact product. Every image you make in this chat must reproduce it exactly.
Product: round coaster, 4 inches (10 cm) diameter, thin disc about 1 cm thick. Top is a flat MATTE digitally printed terrazzo pattern, not real stone and not glossy: an off-white base densely covered in small flat chips, mostly orange and coral, with teal, deep green, warm grey, mustard, maroon, a few small blue chips, semi-transparent white and pale grey chips, and fine black speckle. Chips are small and sparse-to-medium at normal viewing distance, exactly as in the photos. The coaster edge is plain white. The base is brown cork. The holder is gold wire with U-shaped arch loops and a flat base; coasters sit horizontally stacked inside it.
Do not: add gloss, depth, raised chips or polish; enlarge the chips; increase colour saturation; change the chip colours; add colour to the edge; make it look like a sticker on a white disc. Keep colours muted and true to the photos.
Reply "ready" and wait for my scene.
```

---

## Canva text sheet (VA: follow this exactly, type nothing else)

**Canvas:** 2000 × 2000 px. **Safe margin:** 120 px from every edge (nothing closer). **Fonts:** only Josefin Sans and DM Sans. Never Josefin Thin or Light.

| Element | Font | Size | Colour | Rule |
|---|---|---|---|---|
| Headline | Josefin Sans SemiBold | 110 px | Espresso #3E2C23 | Top-left, 120 px margin. Sentence case, exactly as written below |
| Sub-line | DM Sans Regular | 56 px | Espresso #3E2C23 | 30 px under the headline, left-aligned |
| Callout label | DM Sans Medium | 44 px | Espresso #3E2C23 | Max 3 per image. Thin Espresso line (3 px) from the label to a 14 px Honey #D9A441 dot ON the product part it names |
| Badge | Circle 320 px, Sand #D8C3A5 fill, no outline | Text: Josefin Sans SemiBold 64 px + DM Sans Regular 36 px | Espresso #3E2C23 | Bottom-right, 120 px margin. One per image |
| Tagline | Josefin Sans Regular | 96 px | Terracotta #B5603F | Only on slots 3 and 9 |
| Text card (lifestyle slots) | Rectangle, Linen #F3ECE2, corner radius 24 px, 60 px padding | — | — | Text goes on the card, never straight onto a busy photo |
| Logo | Real file from `docs/brand-guidelines-for-visuals/references/logo/` (frameless, Espresso) | 360 px wide | — | Slot 9 only. Never type "ilohaus" as text |

Don'ts: no other colours (no blue, no black, no pure white text), no shadows/outlines/gradients on text, no emojis, no exclamation marks.

**Exact text per slot** (copy-paste, don't reword):

| Slot | Headline | Sub-line | Callouts (→ points at) | Badge / other |
|---|---|---|---|---|
| 1 MAIN | — | — | — | NO text, NO logo. White #FFFFFF background |
| 2 HOOK | Soaks up the drips | Protects wood, glass and stone. | Absorbent stone top → face of the standing coaster · Non-slip cork base → cork inset · Terrazzo-look print → front of the stack | Badge: **4 in** / 10 cm |
| 3 LIFE | — | — | none | Linen card upper-left with tagline: **Joy lives here.** |
| 4 DETAIL | Terrazzo look. Matte finish. | — | Matte terrazzo-look print → top surface · Diatomite ceramic stone → coaster edge | none |
| 5 PROOF | Watch it soak in | Dry in seconds. | Panel labels under each photo, DM Sans Medium 44 px: Drop · 3 sec · 6 sec · Dry (3 panels: Drop · 3 sec · Dry) | Small line bottom-left, DM Sans Regular 32 px: Tested on our Terra print. Same stone in every set. |
| 6 SET | Set of 6 + holder | All six share one design. | none | Number line under the photo, Josefin Sans SemiBold 64 px: **6 coasters · 1 holder** |
| 7 SIZE | Fits every mug | — | none | Dimension line: 3 px Espresso line with end ticks across one coaster, label DM Sans Medium 48 px: **4 in / 10 cm** |
| 8 GIFT | A housewarming they'll use | — | Holder included → the gold holder | none |
| 9 CLOSE | — | — | none | Linen band across bottom 18% of image; tagline **Joy lives here.** centred in the band; logo centred above the tagline, inside the band |

Words that must NEVER appear on any image: Handcrafted · real terrazzo · stone chips · stain-proof · coffee-proof · dishwasher safe · heat-proof · gift box · vibrant · Dolomite · best · premium · sale.

---

## Slot 1 · MAIN — no Gemini
Repo: main image is never generated. Canva Background Remover on `ref-03` → pure white #FFFFFF, 2000×2000, product ~85% of frame, no text/props/logo. Ref-03 already shows all 6 + holder (1 upright, 5 stacked).

## Slot 2 · HOOK — "Soaks up the drips" — Gemini v2
v1 (2026-10-21) failed: 7 coasters (prompt said "seventh view"), holder drawn with one arch and the stack outside it, upright coaster floating, leaning cork coaster oversized with a thick rim, 4:3 not square. v2 fixes count, holder and cork. Run in a NEW chat: product lock first, refs `ref-03` + `_all-variants/ref-cork-base.jpg`.
```
Square 1:1 product photo. Plain seamless background and smooth, hard, matte tabletop, both warm linen colour (#F3ECE2), no fabric, no texture.

EXACTLY SIX coasters in total, no more, no fewer:
- Four coasters lying flat, stacked inside the gold wire holder.
- One coaster standing upright at the back of the holder, resting in it, print side facing the camera, exactly as in the first reference photo.
- One coaster lying flat on the table in front of the holder, slightly to the left, CORK SIDE UP.
Count them before you finish: 4 stacked + 1 upright + 1 cork-up = 6.

The holder must match the reference exactly: thin round gold wire, a flat wire base, and U-shaped arches rising on BOTH the left side and the right side (two arches per side, one front and one back). The stack sits fully inside the holder between the arches, nothing hanging outside it. The upright coaster is held by the back arches, not floating.

The cork-up coaster: identical size to the other coasters, 4 inches across, never larger. Its top is a flat disc of fine-grained brown cork, inset with a THIN white ceramic rim of about 2 mm showing around it, as in the cork reference. It lies completely flat, seen at the same camera angle as the table, so it reads as an ellipse.

Camera straight-on at slight elevation, same angle as the first reference photo. Holder group slightly right of centre; whole product group fills 60 to 70 percent of the frame. Empty clean linen space across the top 20 percent. Soft warm daylight from the left, gentle contact shadows to the right. Matte print, muted true colours. No props, no water, no glass, no text, no blue anywhere.
```
If Gemini still miscounts, reply in the same chat: "Wrong count. Remove one coaster from the stack so there are exactly 4 stacked, 1 upright, 1 cork-up." If the holder is still wrong: "Redraw the holder to match the first reference photo exactly: arches on both left and right sides; keep everything else."
QC before Canva: count = 6 · holder has arches on both sides · nothing floating · cork coaster same size as the others, thin rim · square · print matches ref-03.
Canva text: see text sheet (slot 2). The "Non-slip cork base" callout points at the cork-up coaster.

## Slot 3 · LIFE — "Joy lives here." (Setting A, living room)
Extra ref: `ref-05-lifestyle-tea-topdown.jpg`
```
Candid lifestyle photo, close crop, slight high angle. Two friends relaxing on a cream linen sofa in the afternoon, seen only as a knee in soft-focus beige trousers and a forearm in an oatmeal knit sleeve reaching for a drink; no faces. In the foreground a warm oak coffee table with visible grain holds two iced lattes in ribbed glasses with condensation, each sitting on one of my terrazzo coasters, a small plate of cookies with a few crumbs, an open home magazine, and a woven rattan tray holding the gold holder with the rest of the coasters stacked inside. Dried pampas in a terracotta ceramic vase at the edge. Low golden afternoon sun from the LEFT through a window, long soft shadows, slight warm haze. Coasters clearly visible and sharp, filling about 30 percent of the frame; the print must match the reference exactly, matte, muted true colours. Clean, softly lit wall area in the upper left for text. No blue items, no glossy marble, no screens, no text, no logos.
candid lifestyle photo, lived-in home, golden hour sunlight through a window, warm cozy atmosphere, soft haze, natural clutter, shallow depth of field, editorial home magazine style, not a studio, not minimalist
```
Canva: "Joy lives here." on a Linen card (radius 24px), upper-left, 6% margin. Max 1 callout or none.
QC: v1 (empty oak table, one hand) was rejected as too clean. Need two people's hands/knees, food, clutter.

## Slot 4 · DETAIL — "Terrazzo look. Matte finish."
Extra ref: `TZ-001-001_B0BZNYDNTS/ref-06-macro-print-edge-iced-latte.jpg` (edge/matte only, NOT the print)
```
Macro product photo of ONE of my coasters lying flat on a smooth, hard, matte warm oak surface, camera low at about 25 degrees, focus on the front third of the top surface and the plain white edge. Warm raking light from the left skims across the top to show it is a flat matte print with a fine, slightly granular stone texture, no gloss, no reflections, no raised or embossed chips. Print reproduced exactly from the reference: small flat chips, mostly orange and coral, with teal, deep green, grey, mustard, maroon and a few small blue chips on off-white. Colours muted and true, not saturated. Shallow depth of field, back of the coaster softly blurred. Clean empty space on the right third for callouts. No props, no drinks, no fabric, no text, no blue objects.
```
Canva: headline "Terrazzo look. Matte finish." · callouts: Matte terrazzo-look print · Diatomite ceramic stone. QC: compare against ref-05/ref-07 at arm's length; if the macro reads denser or brighter than the in-use photos, mute it.

## Slot 5 · PROOF — "Watch it soak in" — no Gemini
Real photos only: `_all-variants/ref-absorb-1-0s`, `-2-3s`, `-3-6s` (optional), `-4-dry`. Canva: 3 or 4 equal panels left→right, labels "Drop" · "3 sec" · "6 sec" · "Dry". Crop tight on the wet patch. Optional thin Espresso circle round the patch. Say "Dry in seconds", never "dries in 9 seconds" (one test only).
**Flag:** these photos are the COS-TERRA print (big terracotta/black/mustard shards), visibly not TZM. Crop so the print is background, and add a small DM Sans line: "Tested on our Terra print. Same stone in every set." Honest beats a buyer spotting a different coaster.

## Slot 6 · SET — "Set of 6 + holder" — no Gemini
Canva on Linen: `ref-08` flat lay (6 coasters, already a real-photo composite) + the ref-03 stack-in-holder cut-out to one side. Big number line: "6 coasters · 1 holder". Colourway name under it. Optional small line: "All six share one design."

## Slot 7 · SIZE — "Fits every mug"
```
Product photo on a smooth, hard, matte warm oak table, soft daylight from the left, camera at a 3/4 high angle. Two of my coasters side by side: on the left, a plain cream ceramic coffee mug sits on one coaster with a woman's hand holding its handle (natural relaxed grip, five fingers, short neutral nails, oatmeal knit sleeve); on the right, a stemmed wine glass with a little red wine sits on the other coaster. Correct scale: coaster is 4 inches / 10 cm across, slightly wider than the mug base and the glass foot, with a thin ring of coaster visible all round; the coaster is never as big as the mug. Print exactly as the reference, matte, muted colours, plain white edge. Clean empty space below the coasters for a dimension line. No other props, no fabric, no text, no blue.
```
Canva: headline "Fits every mug" · dimension line across one coaster "4 in / 10 cm". QC: count fingers; coaster wider than mug base.

## Slot 8 · GIFT — "A housewarming they'll use"
**The box is out.** The only box asset is a 3D mock-up printed "Handcrafted" (do-not-claim) and Gemini would garble its text. Gift box included is also TBC. So this slot shows a gift moment without the box until a real photo of the shipped box exists.
```
Candid lifestyle photo at a front door threshold, warm afternoon light from the left. Close crop on two pairs of hands: one person handing the other my coasters stacked in the gold wire holder, tied once around with a loose natural linen ribbon in sand colour and a small blank kraft gift tag. Recipient wears a cream knit sleeve, giver an oatmeal coat sleeve; no faces. Soft-focus background of a warm hallway with a woven doormat and a potted green plant. The coasters and holder are sharp and fill about 35 percent of the frame; print exactly as the reference, matte, muted true colours. Clean softly lit area upper right for text. No boxes, no writing on the tag, no blue, no text.
candid lifestyle photo, lived-in home, golden hour sunlight through a window, warm cozy atmosphere, soft haze, natural clutter, shallow depth of field, editorial home magazine style, not a studio, not minimalist
```
Canva: "A housewarming they'll use" · one callout "Holder included". Do not write "gift box" or "Ready to gift" until the box is confirmed.

## Slot 9 · CLOSE — "Joy lives here."
```
Candid lifestyle photo, slight high angle, close crop on a warm oak coffee table in a living room in the late afternoon. Three pairs of hands around mugs of coffee and a latte, mid-conversation, cream and oatmeal knit sleeves, no faces. Each mug sits on one of my terrazzo coasters; the gold holder with the remaining coasters is on a woven rattan tray at the side, beside a small plate of cookies and an open book. Low golden sun from the LEFT, long soft shadows, warm haze. Coasters sharp and true to the reference, matte. Keep the bottom 20 percent of the frame as calm, plain table surface (it will be covered by a band). No blue, no text, no logos.
candid lifestyle photo, lived-in home, golden hour sunlight through a window, warm cozy atmosphere, soft haze, natural clutter, shallow depth of field, editorial home magazine style, not a studio, not minimalist
```
Canva: Linen band across the bottom, "Joy lives here." centred, real ilohaus logo file (frameless, Espresso). Honey accent only, under 10%.

---

## Do-not-claim (every slot)
Handcrafted · real terrazzo / real stone chips · stain-proof / coffee-proof · dishwasher safe · heat-proof / trivet · gift box included · "vibrant" · "Dolomite".

## File naming
Raw Gemini: `01-terrazzo-coasters/raw/2026-10-21_0N-<slot>-gemini-pro.png` · Canva finals: `01-terrazzo-coasters/for-approval/2026-10-21_0N-<slot>.jpg` (Drive: ilohaus Creative Library).
