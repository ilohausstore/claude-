# Listing plan: Terrazzo Coasters Set of 6 with Holder

Image codes and sequences: `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md`.

- Line: core (Honey, "Joy lives here.")
- Sequence: A (adjusted from reviews)
- Top objections (reviews): Pattern is printed, not real terrazzo (expectation gap); colours less vibrant than photos; print slightly bleeds on edges; 'overpriced' unless on sale; stone chips if dropped
- Top reasons people buy: Absorbs well; sturdy; holder keeps them together; pattern hides coffee rings; looks great on MCM tables

| Slot | Code | Buyer question | Headline | Callouts / proof | Scene | Status |
|---|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White: 6 coasters fanned + holder | Draft |
| 2 | HOOK (second main image) | Will it protect my table? | Soaks up the drips | Sub-line "Protects wood, glass and stone." · Absorbent stone top · Non-slip cork base · Terrazzo-look print (max 3 callouts) · Badge: 4 in / 10 cm | **Product first** (08 §2a): stack of 6 in the gold holder, same angle as MAIN, 60–70% of frame, on Linen; second coaster flipped to show cork. Small sweating iced glass on one coaster only if the print stays visible. No diagram, no timeline, no blue water/graphics. Must pass the 300px test | Brief ready |
| 3 | LIFE | How will it look? | Joy lives here. | — | Lived-in (03): two friends on a sofa, afternoon sun, iced lattes on terrazzo coasters on a wood coffee table, a plate of cookies, open magazine, woven tray with the coaster holder, a knee and sleeve in soft focus. Close crop; coasters clearly visible and true to the reference print. v1 (empty oak table, one hand, iced latte) rejected by Sharon: too clean | Brief ready |
| 4 | DETAIL | What does it really look like? | Terrazzo look. Matte finish. | Matte terrazzo-look print · Diatomite ceramic stone | Macro of top + edge in raking warm light, muted true colours | Brief ready |
| 5 | DETAIL (proof) | Does it really absorb? | Watch it soak in | Frames: "Drop" · "3 sec" · "6 sec" · "Dry" | **Real photo series of one of our terrazzo coasters, any variant** (same stone in every SKU). Crop tight on the water drop so the print is background, not the subject; one shoot serves all 18 variants. Never AI: a faked absorption test is a fake test result. Photos: `references/_all-variants/ref-absorb-1-0s` … `4-dry` (real test, dry at about 9 s). Use frames 1, 2 and 4 if 3 panels read better; a thin Espresso circle may mark the wet patch | Brief ready |
| 6 | SET | What do I get? | Set of 6 + holder | Colourway name | Flat lay of 6 + holder | Draft |
| 7 | SIZE | Will my mug fit? | Fits every mug | 4 in / 10 cm dimension line | Coaster under a mug and wine glass, hand in frame | Draft |
| 8 | GIFT | Can I gift it? | A housewarming they'll use | Holder · Ready to gift | Coasters in packaging on linen | Draft |
| 9 | CLOSE | Who is ilohaus? | Joy lives here. | Logo | Hands, coffee, coasters, Linen band | Draft |

**Dropped:** USES ("Not just for drinks") — lowest-value buyer question; its place goes to the absorption proof.

**Current live image 2 (Oct 2026), to be replaced:** "Superior Absorbency" exploded-layer diagram + grey-disc timeline. Problems: product too small for the search carousel; timeline doesn't show our coaster; says **"Dolomite"** (product is **diatomite**); "Vibrant design" callout widens the 'less vibrant than photo' gap; blue water and blue bars. Keep the idea (proof of absorption), move it to slot 5 with real photos.

**Note:** Slot 2 must also fix the expectation gap: say 'terrazzo-print' or 'terrazzo-look' honestly in copy. Show colours true to life; over-saturated photos are driving 3-star reviews.

## Changelog
- 2026-10-21: Slot 3 re-briefed lived-in; v1 too clean.
- 2026-10-21: Slot 5 unblocked: real absorption photos in _all-variants (COS-TERRA). Frame labels set to real timings.
- 2026-10-20: Slot 5 absorption photos can be any variant (same material); shared across all SKUs.
- 2026-10-20: Slot 2 rebuilt as the second main image (product large, same angle as MAIN; holder + size added). Absorption proof moved to new slot 5 (real photo series only). USES dropped; SET → 6, SIZE → 7. Live image 2 issues logged (Dolomite error, blue graphics, "vibrant").
- 2026-10-20: Slots 2–4 briefed for TZM-001-001. Slot 2 headline "Soaks up every drop" → "Soaks up the drips" (claim is condensation, not spills); "water beading" dropped (beading = not absorbing). Slot 4 "Made to last" dropped (unsupported; reviews mention chips) → answers the printed-not-real / colour complaints.
- 2026-10-19: Draft plan from listing + reviews. Needs Sharon's review before production.
