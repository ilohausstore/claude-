# <Product name>

- **Line:** core | faith
- **Parent ASIN:**
- **Status:** draft | complete (all fields filled, references added, checked)
- **Owner:**

Files: `product-facts.md` (what's true), `visual-identity.md` (how it should look), `asset-evidence.md` (proof for each detail), `listing-plan.md` (the 9-image plan), `references/` (small photos the AI must open).
