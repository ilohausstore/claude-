# Listing plan: <Product name>

See `docs/brand-guidelines-for-visuals/08-listing-images-feel-and-mood.md` for image codes and sequences.

- Line: core | faith
- Sequence: A | B | C | D | E | custom
- Top 3 objections (reviews, returns, Q&A):
- Top 3 reasons people buy (reviews + SQP):

| Slot | Code | Buyer question | Headline (2–5 words) | Callouts / proof | Scene |
|---|---|---|---|---|---|
| 1 | MAIN | What is it? | — | — | White |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | CLOSE | | Joy / Hope lives here. | Logo | |

**Where the work comes from:** the weekly Creative Queue (`creative-queue-YYYY-MM-DD.xlsx`, Tuesdays) picks the ASIN and, on its "3 Creative Brief" tab, which images to rebuild. This plan is the standing design for each slot. If the brief asks for an image this plan doesn't cover, the brief wins: add or update the row here. Work status is tracked in `ilohaus-work-log.xlsx`, not in this file.

Creative Brief → slot code: Hero = MAIN · Proof-of-claim = HOOK or DETAIL · In-room = LIFE · What's in the box = SET · Scale = SIZE · Gift = GIFT.

## Changelog
- YYYY-MM-DD: Created.
