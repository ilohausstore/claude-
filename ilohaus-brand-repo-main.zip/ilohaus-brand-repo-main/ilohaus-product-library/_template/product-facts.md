# Product facts: <Product name>

Only facts backed by the live listing, supplier spec or a photo in `asset-evidence.md`. If unsure, leave blank and mark `TBC`. The AI will not claim anything not listed here.

## Identity
- line: core | faith
- brand_store_page: Home | Faith
- product_name (listing):
- short_name (internal):
- parent_asin:
- child_asins (variation → ASIN):
- marketplaces: US / CA / AU

## What it is
- one-line description:
- set_contents (exact pieces and count):
- variations (colours/designs):

## Specs
- dimensions_cm:
- dimensions_in:
- weight:
- material:
- finish / glaze:
- base (cork, felt, none):
- care (dishwasher, microwave, hand wash):

## Faith only
- verse(s) on product, exact text:
- reference:
- translation: KJV | WEB
- verse checked against source by / date:

## Supported claims (benefit → evidence)
| Claim | Evidence |
|---|---|
|  |  |

## Do NOT claim
- 

## Buyer
- who buys it:
- top use cases / occasions:
- top review praise (paraphrased):
- top review complaints (what images should pre-empt):

## Packaging
- box type / colour:
- insert:

## Changelog
- YYYY-MM-DD: Created.
