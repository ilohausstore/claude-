# Visual identity: <Product name>

Product-specific visual rules. These override general brand guidelines where they're more specific.

## How the product must look
- shape / silhouette:
- colours (name + nearest palette tone):
- texture / finish to show:
- details that must be visible:
- details AI usually gets wrong:

## Hero angle
- best angle:
- product size in frame:

## Accent colour
- core → Honey | faith → Olive

## Scene preferences
- best scenes:
- props allowed:
- props never:

## Approved past images
- (link to OneDrive file + what was good about it)

## Rules learned from feedback
- 

## Changelog
- YYYY-MM-DD: Created.
