# Asset evidence: <Product name>

Which original file supports each visual detail. The AI opens files in `references/` before generating. Heavy originals stay in OneDrive; paste the path.

## In this repo (references/)
| File | What it shows | Use it for |
|---|---|---|
| ref-01-front.jpg |  |  |
| ref-02-set-flatlay.jpg |  |  |
| ref-03-macro-texture.jpg |  |  |
| ref-04-base.jpg |  |  |
| ref-05-scale-in-hand.jpg |  |  |
| ref-06-packaging.jpg |  |  |

## In OneDrive (originals)
| Path | What it is |
|---|---|
| OneDrive\CLAUDE VIBE\ilohaus\products\<product>\raw\ |  |
| … \artwork\ (print files, verse artwork) |  |

## Detail → evidence
| Detail | Proven by |
|---|---|
| set count |  |
| glaze colour |  |
| base material |  |
| dimensions |  |
| verse text (faith) |  |

## Changelog
- YYYY-MM-DD: Created.
