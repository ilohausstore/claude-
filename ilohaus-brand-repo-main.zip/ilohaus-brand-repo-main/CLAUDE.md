# ilohaus Brand Repository: how to work here

You are producing images, copy or video for **ilohaus**, an Amazon home-goods brand (coasters, bowls, plates) with a **Faith** collection (journals, notebooks, verse coasters). Every output must look and sound like one brand, whoever runs the task.

## Read order (every task, no exceptions)

1. **This file.**
2. **The product folder** in `ilohaus-product-library/<NN-product>/`: read `product-facts.md`, `visual-identity.md`, `asset-evidence.md`.
3. **Open the reference images** in that product's `references/` folder and say what you see (shape, colour, texture, size cues, text printed on product). Do not generate a product image until you have done this.
4. **The brand guidelines** in `docs/brand-guidelines-for-visuals/`. Always read `01`, `02`, `03`. Then the file for the job:
   - Listing images → `08-listing-images-feel-and-mood.md` and `11-reference-brands.md`
   - A+, Brand Store, social → `09-aplus-store-social-feel-and-mood.md` and `11-reference-brands.md`
   - Ad images or headlines (Display / Sponsored Display, Sponsored Brands) → `10-ads-display-and-sponsored-brands.md`
   - Any copy → `07-copy-and-voice.md`
   - Faith product → `06-faith-collection.md` (mandatory, includes scripture rules)
5. **The skill** for the task in `.claude/skills/<task>/SKILL.md`, if one exists.

## Hard rules

- **Product facts first.** Only show or claim what `product-facts.md` supports. If a detail isn't there, ask. Don't invent dimensions, materials, set counts or features.
- **Which line?** Core line = "Joy lives here." + Honey accent, **no scripture**. Faith = "Hope lives here." + Olive accent. Never mix Honey and Olive in one design.
- **Palette only:** Linen #F3ECE2, Terracotta #B5603F, Espresso #3E2C23, Sand #D8C3A5, Honey #D9A441, Olive #6E7550. **No blue, anywhere.**
- **Fonts:** Josefin Sans (headlines, taglines, verses) and DM Sans (body). Nothing else. No Josefin Thin/Light under 24px or on thumbnails.
- **Never retype or redraw the logo.** Use the file in `docs/brand-guidelines-for-visuals/references/logo/`.
- **Scripture:** KJV or WEB only, reference printed, verse checked word-for-word against the source text.
- **Amazon main image:** pure white background (RGB 255,255,255), product only, fills ~85% of frame, no text, no props, no logo overlay.

## Workflow

Goal → Understand → Read + plan (state which product files, guideline files and skill you'll use) → Make → Check against `03-image-production-playbook.md` checklist → Save to Google Drive → Hand over with a one-line note per file.

### Where images go
All images live in Google Drive, folder **ilohaus Creative Library** (https://drive.google.com/drive/folders/19Y_8Lsxbo62FpcNtDkU6D-lC7usw3YIX), one subfolder per product named like the product library (`01-terrazzo-coasters`, ...):
- `<product>/raw/`: clean AI scenes with no text, before Canva. Keep them so text can be redone later. Name: `YYYY-MM-DD_0N-<slot>-<tool>.png` (e.g. `2026-10-20_03-life-gemini-pro.png`).
- `<product>/for-approval/`: Canva finals, 2000×2000 JPG, for Sharon's approval before Amazon. Name: `YYYY-MM-DD_0N-<slot>.jpg`.
- `output/` in this repo is scratch only (git-ignored). Nothing there is the record.

Revise one image at a time when asked ("change image 03 only"). Do not regenerate the whole set.

## Feedback loop

When the user gives feedback that should apply next time, ask: "Save this as a rule?" If yes, add it to the **most specific** file (product's `visual-identity.md` before brand guidelines), and add a dated line to that file's `## Changelog`. Brand-wide rule changes in `docs/brand-guidelines-for-visuals/` need Sharon or Cheng Zhi's approval.

## Never

- Publish to Amazon, upload to Seller Central, or spend ad money.
- Write into `docs/brand-guidelines-for-visuals/` without approval.
- Save heavy source files (raw photos, PSDs, videos) in this repo. They live in OneDrive; link them in `asset-evidence.md`.

## Git

At the end of a session, if repo files changed: show the diff summary, then commit with a plain message ("Coaster set: product fills 70% of frame in lifestyle shots") and push. `output/` and `tmp/` are not committed.
