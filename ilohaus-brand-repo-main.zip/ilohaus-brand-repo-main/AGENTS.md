# AGENTS.md

Instructions for any AI tool working in this repository (Codex, Gemini, etc.).

**Read `CLAUDE.md` in full and follow it.** It is the single source of truth for how to work here. This file exists only so non-Claude tools find the instructions.
